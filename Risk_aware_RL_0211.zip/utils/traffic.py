"""
Traffic Generation Utilities

Handles service request generation with arrival times,
holding times, and bandwidth demands.
"""
import numpy as np
from typing import List, Optional
from dataclasses import dataclass


@dataclass
class Service:
    """
    Represents a service/lightpath request.
    
    Attributes:
        service_id: Unique identifier
        source: Source node name
        source_id: Source node index
        destination: Destination node name
        destination_id: Destination node index
        arrival_time: Arrival time in seconds
        holding_time: Holding time in seconds
        bit_rate: Requested bitrate in Gbps
        accepted: Whether the service was accepted
        path: Allocated path (if accepted)
        band_id: Allocated band index (if accepted)
        channels: Allocated frequency slots (if accepted)
        modulation: Used modulation format (if accepted)
    """
    service_id: int
    source: str
    source_id: int
    destination: str
    destination_id: int
    arrival_time: float
    holding_time: float
    bit_rate: float
    accepted: bool = False
    path: Optional = None
    band_id: Optional[int] = None
    channels: Optional[np.ndarray] = None
    modulation: Optional = None


class TrafficGenerator:
    """
    Generates dynamic traffic with Poisson arrivals and
    exponential holding times.
    
    This implements a standard M/M/∞ queuing model for
    optical network traffic.
    """
    # TODO: add reading module from pre-generated traffic files
    
    def __init__(self,
                 nodes: List[str],
                 mean_holding_time: float = 900.0,
                 mean_inter_arrival: float = 1.0,
                 bit_rates: List[int] = None,
                 bit_rate_probs: List[float] = None,
                 seed: int = 42):
        """
        Initialize traffic generator.
        
        Args:
            nodes: List of node names
            mean_holding_time: Mean service holding time (seconds)
            mean_inter_arrival: Mean inter-arrival time (seconds)
            bit_rates: List of possible bitrates (Gbps)
            bit_rate_probs: Probability distribution over bitrates
            seed: Random seed for reproducibility
            
        Example:
            >>> nodes = ['0', '1', '2', '3']
            >>> tg = TrafficGenerator(
            ...     nodes=nodes,
            ...     mean_holding_time=900,  # 15 minutes
            ...     mean_inter_arrival=1,   # 1 second between arrivals
            ...     bit_rates=[100, 200, 400, 1000]
            ... )
        """
        nodes = sorted(nodes, key=int)  # Ensure consistent ordering
        self.nodes = nodes
        self.num_nodes = len(nodes)
        self.mean_holding_time = mean_holding_time
        self.mean_inter_arrival = mean_inter_arrival
        
        # Bitrate configuration
        self.bit_rates = bit_rates or [100, 200, 400, 1000]
        if bit_rate_probs is None:
            # Uniform distribution by default
            self.bit_rate_probs = [1.0/len(self.bit_rates)] * len(self.bit_rates)
        else:
            self.bit_rate_probs = bit_rate_probs
        
        # Random number generator
        self.rng = np.random.default_rng(seed)
        
        # State
        self.current_time = 0.0
        self.service_counter = 0
        
        # Node mapping
        # TODO: check why source id and source uid are different in the encoder
        self.node_to_id = {node: idx for idx, node in enumerate(nodes)}
    
    def generate_service(self) -> Service:
        # TODO: add support for non-uniform node selection (e.g., based on traffic matrix)
        """
        Generate next service request.
        
        Returns:
            Service object with arrival time, holding time,
            source, destination, and bitrate
            
        Note:
            Automatically increments current_time and service_counter
        """
        # Generate inter-arrival time (exponential distribution)
        interval = self.rng.exponential(self.mean_inter_arrival)
        self.current_time += interval
        
        # Generate holding time (exponential distribution)
        holding_time = self.rng.exponential(self.mean_holding_time)
        
        # Select source and destination (different nodes)
        src_idx = self.rng.integers(0, self.num_nodes)
        dst_idx = self.rng.integers(0, self.num_nodes)
        while dst_idx == src_idx:
            dst_idx = self.rng.integers(0, self.num_nodes)

        src = self.nodes[src_idx]
        dst = self.nodes[dst_idx]
        
        # Select bitrate from distribution
        bit_rate = self.rng.choice(self.bit_rates, p=self.bit_rate_probs)
        
        # Create service object
        service = Service(
            service_id=self.service_counter,
            source=src,
            source_id=src_idx,
            destination=dst,
            destination_id=dst_idx,
            arrival_time=self.current_time,
            holding_time=holding_time,
            bit_rate=float(bit_rate)
        )
        
        self.service_counter += 1
        return service
    
    def reset(self):
        """
        Reset traffic generator state.
        
        Resets current_time and service_counter to 0.
        """
        self.current_time = 0.0
        self.service_counter = 0
    
    def get_load(self) -> float:
        """
        Calculate offered load (Erlangs).
        
        Load = mean_holding_time / mean_inter_arrival
        
        Returns:
            Offered load in Erlangs
        """
        return self.mean_holding_time / self.mean_inter_arrival
    
    def set_load(self, target_load: float):
        """
        Set traffic load by adjusting inter-arrival time.
        
        Args:
            target_load: Desired load in Erlangs
            
        Note:
            Keeps holding time constant, adjusts inter-arrival time
        """
        self.mean_inter_arrival = self.mean_holding_time / target_load


class StaticTrafficGenerator:
    """
    Static traffic generator that cycles through a pre-defined
    list of services.
    
    Useful for deterministic testing and reproducibility.
    """
    
    def __init__(self, services: List[Service]):
        """
        Initialize with list of services.
        
        Args:
            services: Pre-defined list of Service objects
        """
        self.services = services
        self.index = 0
    
    def generate_service(self) -> Service:
        """
        Get next service from the list (cycles if at end).
        
        Returns:
            Next Service object
        """
        if self.index >= len(self.services):
            self.index = 0
        
        service = self.services[self.index]
        self.index += 1
        return service
    
    def reset(self):
        """Reset to start of service list."""
        self.index = 0
    
    def __len__(self) -> int:
        """Number of services in the list."""
        return len(self.services)
