"""
Spectrum Management Utilities

Handles spectrum allocation, fragmentation computation,
and spectrum-related operations for optical networks.
"""
import numpy as np
from typing import List, Optional


def first_fit_allocation(occ_arrays: List[np.ndarray], 
                        required_slots: int) -> Optional[int]:
    """
    First-Fit spectrum allocation algorithm.
    
    Finds the first contiguous block of free slots across all links.
    
    Args:
        occ_arrays: List of occupancy arrays, one per link
                   (1 = occupied, 0 = free)
        required_slots: Number of contiguous slots needed
        
    Returns:
        Starting slot index if allocation possible, None otherwise
        
    Example:
        >>> link1 = np.array([1, 1, 0, 0, 0, 0, 1, 1])
        >>> link2 = np.array([1, 0, 0, 0, 0, 1, 1, 1])
        >>> start = first_fit_allocation([link1, link2], 3)
        >>> # Returns 2 (slots 2,3,4 are free on both links)
    """
    if not occ_arrays:
        return None
    
    # Get total number of slots
    num_slots_total = len(occ_arrays[0])
    
    # ADDED: Check if requested slots exceed available spectrum
    if required_slots > num_slots_total:
        return None
    
    # ADDED: Calculate maximum valid starting position
    # This prevents allocating beyond array bounds
    max_start_idx = num_slots_total - required_slots
    
    # Compute common free slots (free on ALL links)
    common_free = np.ones_like(occ_arrays[0], dtype=np.int8)
    for occ in occ_arrays:
        common_free &= (1 - occ).astype(np.int8)
    
    # Find first contiguous block of required size
    run_length = 0
    start_idx = 0
    
    for i in range(len(common_free)):
        if common_free[i]:
            if run_length == 0:
                start_idx = i
            run_length += 1
            
            if run_length >= required_slots:
                # ADDED: Verify allocation won't exceed bounds
                if start_idx <= max_start_idx:
                    return start_idx
                else:
                    # Reset and continue searching
                    run_length = 0
        else:
            run_length = 0
    
    return None
    # # Compute common free slots (free on ALL links)
    # common_free = np.ones_like(occ_arrays[0], dtype=np.int8)
    # for occ in occ_arrays:
    #     common_free &= (1 - occ).astype(np.int8)
    
    # # Find first contiguous block of required size
    # run_length = 0
    # start_idx = 0
    
    # for i in range(len(common_free)):
    #     if common_free[i]:
    #         if run_length == 0:
    #             start_idx = i
    #         run_length += 1
            
    #         if run_length >= required_slots:
    #             return start_idx
    #     else:
    #         run_length = 0
    
    # return None


def best_fit_allocation(occ_arrays: List[np.ndarray],
                       required_slots: int) -> Optional[int]:
    """
    Best-Fit spectrum allocation algorithm.
    
    Finds the smallest contiguous block that can accommodate
    the required slots.
    
    Args:
        occ_arrays: List of occupancy arrays
        required_slots: Number of contiguous slots needed
        
    Returns:
        Starting slot index of best-fit block, None if impossible
    """
    # Compute common free slots
    common_free = np.ones_like(occ_arrays[0], dtype=np.int8)
    for occ in occ_arrays:
        common_free &= (1 - occ).astype(np.int8)
    
    # Find all free blocks
    blocks = []
    run_length = 0
    start_idx = 0
    
    for i in range(len(common_free)):
        if common_free[i]:
            if run_length == 0:
                start_idx = i
            run_length += 1
        else:
            if run_length >= required_slots:
                blocks.append((start_idx, run_length))
            run_length = 0
    
    # Check last block
    if run_length >= required_slots:
        blocks.append((start_idx, run_length))
    
    # Return smallest sufficient block
    if not blocks:
        return None
    
    best_block = min(blocks, key=lambda x: x[1])
    return best_block[0]


def compute_spectrum_fragmentation(occ_array: np.ndarray) -> float:
    """
    Compute spectrum fragmentation metric.
    
    Fragmentation = (number of free blocks) / (total free slots)
    Higher value indicates more fragmentation.
    
    Args:
        occ_array: Occupancy array (1=occupied, 0=free)
        
    Returns:
        Fragmentation metric in [0, 1]
        
    Example:
        >>> occ = np.array([0, 1, 1, 0, 0, 1, 0, 0, 0])
        >>> frag = compute_spectrum_fragmentation(occ)
        >>> # Three free blocks: [0], [3,4], [6,7,8]
        >>> # Fragmentation = 3 / 6 = 0.5
    """
    if len(occ_array) == 0:
        return 0.0
    
    # Count free blocks
    free_blocks = 0
    in_free_block = False
    
    for slot in occ_array:
        if slot == 0:  # Free
            if not in_free_block:
                free_blocks += 1
                in_free_block = True
        else:  # Occupied
            in_free_block = False
    
    # Count total free slots
    total_free = np.sum(occ_array == 0)
    
    if total_free == 0:
        return 1.0  # Fully occupied = maximum fragmentation
    
    # Normalize: more blocks = more fragmentation
    # TODO: check the logic here, is there any reference support it?
    fragmentation = min(free_blocks / max(1, total_free), 1.0)
    
    return fragmentation


def compute_largest_free_block(occ_arrays: List[np.ndarray]) -> int:
    """
    Find the size of largest contiguous free block across all links.
    
    Args:
        occ_arrays: List of occupancy arrays
        
    Returns:
        Size of largest common free block
        
    Example:
        >>> link1 = np.array([1, 1, 0, 0, 0, 0, 1])
        >>> link2 = np.array([1, 0, 0, 0, 0, 1, 1])
        >>> size = compute_largest_free_block([link1, link2])
        >>> # Returns 4 (slots 2,3,4,5 free on both)
    """
    # Compute common free slots
    common_free = np.ones_like(occ_arrays[0], dtype=np.int8)
    for occ in occ_arrays:
        common_free &= (1 - occ).astype(np.int8)
    
    # Find largest contiguous block
    max_length = 0
    current_length = 0
    
    for slot in common_free:
        if slot:
            current_length += 1
            max_length = max(max_length, current_length)
        else:
            current_length = 0
    
    return max_length


def compute_spectrum_utilization(occ_array: np.ndarray) -> float:
    """
    Compute spectrum utilization (fraction of occupied slots).
    
    Args:
        occ_array: Occupancy array
        
    Returns:
        Utilization in [0, 1]
    """
    if len(occ_array) == 0:
        return 0.0
    return float(np.mean(occ_array))


def compute_free_blocks_distribution(occ_array: np.ndarray) -> List[int]:
    """
    Get list of all free block sizes.
    
    Args:
        occ_array: Occupancy array
        
    Returns:
        List of free block sizes
        
    Example:
        >>> occ = np.array([0, 0, 1, 0, 1, 0, 0, 0])
        >>> blocks = compute_free_blocks_distribution(occ)
        >>> # Returns [2, 1, 3] (blocks of size 2, 1, and 3)
    """
    blocks = []
    current_size = 0
    
    for slot in occ_array:
        if slot == 0:
            current_size += 1
        else:
            if current_size > 0:
                blocks.append(current_size)
            current_size = 0
    
    # Don't forget last block
    if current_size > 0:
        blocks.append(current_size)
    
    return blocks


def compute_spectrum_entropy(occ_array: np.ndarray, 
                             normalize: bool = True) -> float:
    """
    Compute entropy of spectrum occupancy pattern.
    
    Higher entropy = more random/fragmented pattern.
    
    Args:
        occ_array: Occupancy array
        normalize: Whether to normalize to [0, 1]
        
    Returns:
        Entropy value
    """
    if len(occ_array) == 0:
        return 0.0
    
    # Count occupied and free
    n_occ = np.sum(occ_array)
    n_free = len(occ_array) - n_occ
    
    if n_occ == 0 or n_free == 0:
        return 0.0  # No entropy if all same
    
    # Compute probabilities
    p_occ = n_occ / len(occ_array)
    p_free = n_free / len(occ_array)
    
    # Shannon entropy
    entropy = -(p_occ * np.log2(p_occ + 1e-10) + 
                p_free * np.log2(p_free + 1e-10))
    
    if normalize:
        # Maximum entropy is 1 (when p_occ = p_free = 0.5)
        entropy = entropy / 1.0
    
    return float(entropy)


def allocate_spectrum(occ_arrays: List[np.ndarray],
                     start_slot: int,
                     num_slots: int) -> None:
    """
    Allocate (mark as occupied) spectrum slots.
    
    Args:
        occ_arrays: List of occupancy arrays (modified in-place)
        start_slot: Starting slot index
        num_slots: Number of slots to allocate
        
    Note:
        Modifies occ_arrays in-place!
    """
    end_slot = start_slot + num_slots
    for occ in occ_arrays:
        occ[start_slot:end_slot] = 1


def release_spectrum(occ_arrays: List[np.ndarray],
                    start_slot: int,
                    num_slots: int) -> None:
    """
    Release (mark as free) spectrum slots.
    
    Args:
        occ_arrays: List of occupancy arrays (modified in-place)
        start_slot: Starting slot index
        num_slots: Number of slots to release
        
    Note:
        Modifies occ_arrays in-place!
    """
    end_slot = start_slot + num_slots
    for occ in occ_arrays:
        occ[start_slot:end_slot] = 0
