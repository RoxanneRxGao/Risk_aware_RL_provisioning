"""
Risk-Aware Environment - Updated with Bit-Rate Weighted Rewards

Key Updates:
1. Bit-rate weighted rewards: reward ∝ bitrate
2. Multiple reward schemes (uniform, bitrate_weighted, bitrate_criticality)
3. Tracks rewards for CVaR computation
"""
import gymnasium as gym
from gymnasium import spaces
import numpy as np
import heapq
from typing import Dict, List, Tuple, Optional
import networkx as nx

from utils.topology import Path
from utils.traffic import Service, TrafficGenerator
from utils.spectrum import first_fit_allocation
from utils.qot import slots_needed, SimpleQoTProvider
from envs.state_encoder import StateEncoder, EncoderConfig


class RiskAwareProvisioningEnv(gym.Env):
    """
    Environment with bit-rate weighted rewards for CVaR optimization.
    """
    
    metadata = {"render_modes": []}
    
    def __init__(
        self,
        topology: nx.DiGraph,
        ksp_dict: Dict[Tuple[str, str], List[Path]],
        qot_provider: SimpleQoTProvider,
        edge_criticality: np.ndarray,
        encoder: StateEncoder,
        bands: List[int] = None,
        slots_per_band: int = 400,
        slot_bandwidth_ghz: float = 12.5,
        guard_slots: int = 1,
        K: int = 5,
        episode_length: int = 1000,
        traffic_generator: TrafficGenerator = None,
        use_action_masking: bool = True,
        # NEW: Reward configuration
        reward_scheme: str = "bitrate_weighted",
        reward_accept_base: float = 1.0,
        reward_block_base: float = -1.0,
        bitrate_normalization: float = 1000.0,
        criticality_penalty_weight: float = 0.0,
        seed: int = 42,
        log_file: str = None
    ):
        """
        Initialize environment.
        
        NEW Args:
            reward_scheme: "uniform", "bitrate_weighted", or "bitrate_criticality"
            reward_accept_base: Base reward for acceptance
            reward_block_base: Base penalty for blocking
            bitrate_normalization: Normalization factor (e.g., 1000 Gbps)
            criticality_penalty_weight: Penalty weight for high-criticality paths
        """
        super().__init__()
        
        self.topology = topology
        self.ksp_dict = ksp_dict
        self.nodes = list(topology.nodes())
        self.num_nodes = len(self.nodes)
        self.num_links = topology.number_of_edges()
        
        self.node_to_idx = {node: topology.nodes[node]['index'] for node in self.nodes}
        
        self.bands = bands if bands is not None else [0, 1, 2]
        self.num_bands = len(self.bands)
        self.slots_per_band = slots_per_band
        self.slot_bandwidth_ghz = slot_bandwidth_ghz
        self.guard_slots = guard_slots
        
        self.K = K
        self.episode_length = episode_length
        
        self.qot = qot_provider
        self.edge_criticality = edge_criticality
        self.encoder = encoder
        self.traffic_gen = traffic_generator
        self.use_action_masking = use_action_masking
        
        # NEW: Reward configuration
        self.reward_scheme = reward_scheme
        self.reward_accept_base = reward_accept_base
        self.reward_block_base = reward_block_base
        self.bitrate_normalization = bitrate_normalization
        self.criticality_penalty_weight = criticality_penalty_weight
        
        self.rng = np.random.default_rng(seed)
        
        n_actions = self.K * self.num_bands
        # if self.use_action_masking:
        #     n_actions += 1
        self.action_space = spaces.Discrete(n_actions)
        
        obs_dim = self.encoder.obs_dim()
        self.observation_space = spaces.Box(
            low=-np.inf, high=np.inf, shape=(obs_dim,), dtype=np.float32
        )
        
        self.spectrum_occ = None
        self.current_service = None
        self.current_paths = None
        self.current_mask = None
        self.current_time = 0.0
        self.step_count = 0
        self.release_events = []
        self.episode_stats = None
        
        # NEW: Track rewards for CVaR
        self.step_rewards = []
        
        self.total_services_processed = 0
        self.total_services_accepted = 0

        # Setup logging
        self.log_file = log_file
        self.enable_logging = log_file is not None

        if self.enable_logging:
            import logging
            import os

            # Create log directory if needed
            log_dir = os.path.dirname(log_file)
            if log_dir and not os.path.exists(log_dir):
                os.makedirs(log_dir, exist_ok=True)

            # Setup logger
            self.logger = logging.getLogger(f'RiskAwareEnv_{id(self)}')
            self.logger.setLevel(logging.INFO)
            self.logger.handlers = []
            self.logger.propagate = False  # ← ADD THIS LINE (prevents console output)

            # Track statistics for summary
            self.log_stats = {
                'allocated': 0,
                'blocked': 0,
                'released': 0
            }
            
            # File handler
            fh = logging.FileHandler(log_file, mode='w')
            fh.setLevel(logging.INFO)

            # Formatter
            formatter = logging.Formatter(
                '%(asctime)s | %(message)s',
                datefmt='%Y-%m-%d %H:%M:%S'
            )
            fh.setFormatter(formatter)
            self.logger.addHandler(fh)

            # Log header
            self.logger.info("=" * 80)
            self.logger.info("SERVICE ALLOCATION LOG")
            self.logger.info("=" * 80)
            self.logger.info(f"Topology: {topology.number_of_nodes()} nodes, {topology.number_of_edges()} edges")
            self.logger.info(f"Bands: {len(self.bands)}, Slots per band: {self.slots_per_band}")
            self.logger.info(f"K-paths: {self.K}, Episode length: {self.episode_length}")
            self.logger.info("=" * 80)
            self.logger.info("")

            # Service counter
            self.service_counter = 0
    
    def reset(self, seed: Optional[int] = None, options: Optional[dict] = None):
        """Reset environment."""
        super().reset(seed=seed)
        
        if seed is not None:
            self.rng = np.random.default_rng(seed)
            self.traffic_gen.rng = np.random.default_rng(seed)
        
        self.spectrum_occ = {
            band: np.zeros((self.num_links, self.slots_per_band), dtype=np.int8)
            for band in self.bands
        }
        
        self.current_time = 0.0
        self.step_count = 0
        self.release_events = []
        
        self.episode_stats = {
            'services_processed': 0,
            'services_accepted': 0,
            'total_bitrate_requested': 0.0,
            'total_bitrate_carried': 0.0,
            'total_reward': 0.0,
            'rewards': []  # NEW
        }
        
        self.step_rewards = []  # NEW
        
        self.traffic_gen.reset()
        self._generate_next_service()

        # ADD: Log episode start
        if self.enable_logging:
            self.logger.info("")
            self.logger.info("=" * 80)
            self.logger.info(f"EPISODE START (Total services processed: {self.total_services_processed})")
            self.logger.info("=" * 80)
            self.service_counter = 0
        
        if self.enable_logging and self.service_counter > 0:
          # Print summary (only this shows in console)
          print(f"Episode complete: {self.log_stats['allocated']} allocated, "
                f"{self.log_stats['blocked']} blocked, "
                f"{self.log_stats['released']} released")
        # Reset stats
        self.log_stats = {'allocated': 0, 'blocked': 0, 'released': 0}
        
        obs = self._get_observation()
        return obs, {}
    
    def step(self, action: int):
        """Execute step with bit-rate weighted reward."""
        assert self.action_space.contains(action)
        
        self._process_releases()
        
        self.step_count += 1
        self.episode_stats['services_processed'] += 1
        bitrate = self.current_service.bit_rate
        self.episode_stats['total_bitrate_requested'] += bitrate

        # ADD: Service counter
        if self.enable_logging:
            self.service_counter += 1
            service_id = self.service_counter
        
        accepted = False
        path_criticality = 0.0
        
        # if self.use_action_masking and action == self.action_space.n - 1:
        if self.use_action_masking and action >= self.K * self.num_bands:
            accepted = False
            # ADD: Log blocking
            if self.enable_logging:
                self._log_service_blocked(service_id, "Agent chose to block")
        elif not self.current_mask[action]:
            accepted = False
            # ADD: Log invalid action
            if self.enable_logging:
                self._log_service_blocked(service_id, "Invalid action (masked)")
        else:
            k = action // self.num_bands
            b = action % self.num_bands
            band = self.bands[b]
            
            if k < len(self.current_paths):
                path = self.current_paths[k]
                link_ids = self._path_to_link_ids(path)
                
                if len(link_ids) > 0:
                    path_criticality = np.mean(self.edge_criticality[link_ids])
                
                accepted = self._attempt_allocation(path, band, link_ids)\

                # ADD: Log result
                if self.enable_logging:
                    if accepted:
                        self._log_service_allocated(service_id)
                    else:
                        self._log_service_blocked(service_id, "No spectrum available")
        
        # NEW: Calculate weighted reward
        reward = self._calculate_reward(accepted, bitrate, path_criticality)
        
        if accepted:
            self.episode_stats['services_accepted'] += 1
            self.episode_stats['total_bitrate_carried'] += bitrate
        
        self.current_service.accepted = accepted
        
        # Track reward
        self.episode_stats['total_reward'] += reward
        self.episode_stats['rewards'].append(reward)
        self.step_rewards.append(reward)
        
        self.total_services_processed += 1
        if accepted:
            self.total_services_accepted += 1
        
        terminated = (self.episode_stats['services_processed'] >= self.episode_length)
        truncated = False
        
        info = self._get_step_info(terminated, bitrate, accepted, reward)
        
        if not terminated:
            self._generate_next_service()
            obs = self._get_observation()
        else:
            obs = np.zeros(self.encoder.obs_dim(), dtype=np.float32)
        
        return obs, reward, terminated, truncated, info
    
    def _calculate_reward(self, accepted: bool, bitrate: float, 
                         path_criticality: float) -> float:
        """
        Calculate bit-rate weighted reward.
        
        Schemes:
          uniform: ±1
          bitrate_weighted: ±(bitrate/norm)
          bitrate_criticality: ±(bitrate/norm) - criticality_penalty
        """
        bitrate_norm = bitrate / self.bitrate_normalization
        
        if self.reward_scheme == "uniform":
            reward = self.reward_accept_base if accepted else self.reward_block_base
            
        elif self.reward_scheme == "bitrate_weighted":
            if accepted:
                reward = self.reward_accept_base * bitrate_norm
            else:
                reward = self.reward_block_base * bitrate_norm
                
        elif self.reward_scheme == "bitrate_criticality":
            if accepted:
                criticality_penalty = self.criticality_penalty_weight * path_criticality
                reward = self.reward_accept_base * bitrate_norm - criticality_penalty
            else:
                reward = self.reward_block_base * bitrate_norm
        
        else:
            reward = self.reward_accept_base if accepted else self.reward_block_base
        
        return float(reward)
    
    # def _attempt_allocation(self, path: Path, band: int, link_ids: np.ndarray) -> bool:
    #     """Attempt allocation."""
    #     best_mod = self.qot.get_best_modulation(path.path_id)
    #     if best_mod is None:
    #         return False
    #
    #     required_slots = slots_needed(
    #         self.current_service.bit_rate,
    #         best_mod.spectral_efficiency,
    #         self.slot_bandwidth_ghz,
    #         self.guard_slots
    #     )
    #
    #     occ_arrays = [self.spectrum_occ[band][lid] for lid in link_ids]
    #     start_slot = first_fit_allocation(occ_arrays, required_slots)
    #
    #     if start_slot is None:
    #         return False
    #
    #     self._allocate_spectrum(band, link_ids, start_slot, required_slots)
    #
    #     self.current_service.path = path
    #     self.current_service.band_id = band
    #     self.current_service.channels = np.arange(start_slot, start_slot + required_slots)
    #     self.current_service.modulation = best_mod
    #
    #     release_time = self.current_time + self.current_service.holding_time
    #     heapq.heappush(self.release_events, (release_time, self.current_service))
    #
    #     return True

    def _get_modulation_for_gsnr(self, gsnr_db: float):
        """
        Select best modulation for given GSNR.

        Args:
            gsnr_db: Actual GSNR in dB

        Returns:
            Best modulation or None
        """
        feasible_mods = []

        for mod in self.qot.modulations:
            # Check both GSNR and length constraints
            if gsnr_db >= mod.minimum_osnr:
                feasible_mods.append(mod)

        if not feasible_mods:
            return None

        # Return modulation with highest spectral efficiency
        return max(feasible_mods, key=lambda m: m.spectral_efficiency)

    def _attempt_allocation(self, path, band: int, link_ids: np.ndarray) -> bool:
        """
        Improved allocation with actual GSNR checking.
        """
        # Step 1: Get worst-case modulation for initial estimate
        worst_mod = self.qot.get_best_modulation(path.path_id)
        if worst_mod is None:
            return False

        # Step 2: Calculate worst-case slot requirement
        worst_case_slots = slots_needed(
            self.current_service.bit_rate,
            worst_mod.spectral_efficiency,
            self.slot_bandwidth_ghz,
            self.guard_slots
        )

        # Step 3: Find available spectrum
        occ_arrays = [self.spectrum_occ[band][lid] for lid in link_ids]
        start_slot = first_fit_allocation(occ_arrays, worst_case_slots)

        if start_slot is None:
            return False

        # Step 4: CHECK ACTUAL GSNR at found position (NEW!)
        if hasattr(self.qot, 'get_slot_gsnr'):
            # Get actual GSNR at these specific slots
            end_slot = start_slot + worst_case_slots
            actual_gsnr = self.qot.get_slot_gsnr(
                path.path_id,
                start_slot,
                num_slots=worst_case_slots
            )

            # Select best modulation for ACTUAL GSNR
            actual_mod = self._get_modulation_for_gsnr(
                actual_gsnr.min(),  # Use minimum GSNR in range
            )

            if actual_mod is None:
                return False

            # Calculate actual slots needed (may be LESS!)
            actual_slots = slots_needed(
                self.current_service.bit_rate,
                actual_mod.spectral_efficiency,
                self.slot_bandwidth_ghz,
                self.guard_slots
            )

            # Use better modulation if possible
            best_mod = actual_mod
            required_slots = actual_slots

        else:
            # No slot-specific GSNR, use worst-case
            best_mod = worst_mod
            required_slots = worst_case_slots

        # Step 5: Allocate actual required slots
        # Add explicit bounds check to prevent out-of-bounds allocation
        if start_slot + required_slots > self.slots_per_band:
            # print(f"⚠️ ERROR: Allocation would exceed spectrum bounds!")
            # print(f"   Start: {start_slot}, Required: {required_slots}, Max: {self.slots_per_band}")
            return False
        
        self._allocate_spectrum(band, link_ids, start_slot, required_slots)

        self.current_service.path = path
        self.current_service.band_id = band
        self.current_service.channels = np.arange(start_slot, start_slot + required_slots)
        self.current_service.modulation = best_mod

        # ADD: Store service ID for logging
        if self.enable_logging:
            self.current_service.service_id = self.service_counter

        release_time = self.current_time + self.current_service.holding_time
        heapq.heappush(self.release_events, (release_time, self.current_service))

        return True
    
    def _allocate_spectrum(self, band: int, link_ids: np.ndarray, 
                          start_slot: int, num_slots: int):
        """Allocate spectrum."""
        end_slot = start_slot + num_slots
        
        # Bounds should already be checked by caller, but add assertion for safety
        assert start_slot + num_slots <= self.slots_per_band, \
            f"Allocation exceeds bounds: {start_slot} + {num_slots} > {self.slots_per_band}"

        for lid in link_ids:
            self.spectrum_occ[band][lid, start_slot:end_slot] = 1
    
    def _release_spectrum(self, service: Service):
        """Release spectrum."""
        if not service.accepted or service.path is None:
            return

        # ADD: Log release
        if self.enable_logging:
            self._log_service_released(service)

        band = service.band_id
        link_ids = self._path_to_link_ids(service.path)

        max_slot = self.spectrum_occ[band].shape[1]
        valid_channels = service.channels[service.channels < max_slot]

        if len(valid_channels) != len(service.channels):
            print(f"⚠️ Warning: Service has channels out of bounds!")
            print(f"   Max slot: {max_slot}, Channels: {service.channels}")
        
        for lid in link_ids:
            self.spectrum_occ[band][lid, service.channels] = 0
    
    def _generate_next_service(self):
        """Generate next service."""
        service = self.traffic_gen.generate_service()
        self.current_time = service.arrival_time
        
        key = (service.source, service.destination)
        if key in self.ksp_dict:
            self.current_paths = self.ksp_dict[key][:self.K]
        else:
            self.current_paths = []
        
        self.current_service = service
    
    def _process_releases(self):
        """Process releases."""
        while self.release_events and self.release_events[0][0] <= self.current_time:
            release_time, released_service = heapq.heappop(self.release_events)
            self._release_spectrum(released_service)
    
    def _path_to_link_ids(self, path: Path) -> np.ndarray:
        """Path to link IDs."""
        if path.links_id is not None:
            return path.links_id
        
        link_ids = []
        for i in range(len(path.node_list) - 1):
            u = path.node_list[i]
            v = path.node_list[i + 1]
            link_id = self.topology[u][v]['index']
            link_ids.append(link_id)
        
        return np.array(link_ids, dtype=np.int32)
    
    def _get_observation(self) -> np.ndarray:
        """Get observation."""

        obs, mask = self.encoder.encode(
            service=self.current_service,
            paths=self.current_paths,
            occ_by_band_by_link=self.spectrum_occ,
            path_to_link_ids_fn=self._path_to_link_ids
        )
        
        self.current_mask = mask
        return obs
    
    def action_masks(self) -> np.ndarray:
        """Action mask."""
        if self.current_mask is None:
            self._get_observation()
        return self.current_mask.astype(bool)
    
    # def _get_step_info(self, is_terminal: bool, bitrate: float,
    #                   accepted: bool, reward: float) -> Dict:
    #     """Get step info."""
    #     info = {
    #         'accepted': accepted,
    #         'step': self.step_count,
    #         'bitrate': bitrate,
    #         'reward': reward
    #     }
    #
    #     if is_terminal:
    #         stats = self.episode_stats
    #
    #         service_blocking = 0.0
    #         bitrate_blocking = 0.0
    #
    #         if stats['services_processed'] > 0:
    #             service_blocking = 1.0 - (stats['services_accepted'] / stats['services_processed'])
    #
    #         if stats['total_bitrate_requested'] > 0:
    #             bitrate_blocking = 1.0 - (stats['total_bitrate_carried'] / stats['total_bitrate_requested'])
    #
    #         info.update({
    #             'episode_service_blocking_rate': service_blocking,
    #             'episode_bit_rate_blocking_rate': bitrate_blocking,
    #             'episode_services_processed': stats['services_processed'],
    #             'episode_services_accepted': stats['services_accepted'],
    #             'episode_bitrate_requested': stats['total_bitrate_requested'],
    #             'episode_bitrate_carried': stats['total_bitrate_carried'],
    #             'episode_total_reward': stats['total_reward'],
    #             'episode_mean_reward': np.mean(stats['rewards']),
    #             'episode_reward_std': np.std(stats['rewards']),
    #             'episode_rewards': np.array(stats['rewards']),  # For CVaR
    #         })
    #
    #     return info
    def _get_step_info(self, is_terminal: bool, bitrate: float,
                       accepted: bool, reward: float) -> Dict:
        """Get step info."""
        info = {
            'accepted': accepted,
            'step': self.step_count,
            'bitrate': bitrate,
            'reward': reward
        }

        if is_terminal:
            stats = self.episode_stats

            service_blocking = 0.0
            bitrate_blocking = 0.0

            if stats['services_processed'] > 0:
                service_blocking = 1.0 - (stats['services_accepted'] / stats['services_processed'])

            if stats['total_bitrate_requested'] > 0:
                bitrate_blocking = 1.0 - (stats['total_bitrate_carried'] / stats['total_bitrate_requested'])

            # CRITICAL: Add standard 'episode' key for Monitor/Callbacks compatibility
            info['episode'] = {
                'r': stats['total_reward'],  # Total episode return
                'l': stats['services_processed'],  # Episode length
                't': self.current_time  # Episode time (optional)
            }

            # Additional custom metrics
            info.update({
                'episode_service_blocking_rate': service_blocking,
                'episode_bit_rate_blocking_rate': bitrate_blocking,
                'episode_services_processed': stats['services_processed'],
                'episode_services_accepted': stats['services_accepted'],
                'episode_bitrate_requested': stats['total_bitrate_requested'],
                'episode_bitrate_carried': stats['total_bitrate_carried'],
                'episode_total_reward': stats['total_reward'],
                'episode_mean_reward': np.mean(stats['rewards']) if len(stats['rewards']) > 0 else 0.0,
                'episode_reward_std': np.std(stats['rewards']) if len(stats['rewards']) > 0 else 0.0,
                'episode_rewards': np.array(stats['rewards']),  # For CVaR
            })

        return info
    
    def render(self):
        pass
    
    def close(self):
        pass

    def _log_service_allocated(self, service_id):
        """Log successful allocation."""
        if not self.enable_logging:
            return

        self.log_stats['allocated'] += 1

        s = self.current_service
        channels = s.channels
        start_slot = int(channels[0])
        end_slot = int(channels[-1])
        num_slots = len(channels)

        band_name = ['C', 'L', 'S'][s.band_id] if s.band_id < 3 else f'Band{s.band_id}'
        # path_str = s.source + ' → ' + s.destination

        self.logger.info(
            f"[{service_id:05d}] ✓ ALLOCATED | "
            f"{s.source} → {s.destination} | "
            f"{s.bit_rate}G | "
            f"{band_name}-band | "
            f"Slots {start_slot}-{end_slot} ({num_slots} slots) | "
            f"Mod: {s.modulation.name} | "
            # f"Path: {path_str} | "
            f"Arrival: {s.arrival_time:.2f}s | "
            f"Holding: {s.holding_time:.1f}s"
        )

    def _log_service_blocked(self, service_id, reason):
        """Log blocked service."""
        if not self.enable_logging:
            return
        self.log_stats['blocked'] += 1

        s = self.current_service
        self.logger.info(
            f"[{service_id:05d}] ✗ BLOCKED | "
            f"{s.source} → {s.destination} | "
            f"{s.bit_rate}G | "
            f"Arrival: {s.arrival_time:.2f}s | "
            f"Reason: {reason}"
        )

    def _log_service_released(self, service):
        """Log service release."""
        if not self.enable_logging or not hasattr(service, 'service_id'):
            return

        self.log_stats['released'] += 1

        channels = service.channels
        start_slot = int(channels[0])
        end_slot = int(channels[-1])
        band_name = ['C', 'L', 'S'][service.band_id] if service.band_id < 3 else f'Band{service.band_id}'

        self.logger.info(
            f"[{service.service_id:05d}] ⟲ RELEASED | "
            f"{service.source} → {service.destination} | "
            f"{service.bit_rate}G | "
            f"{band_name}-band | "
            f"Slots {start_slot}-{end_slot} | "
            f"Time: {self.current_time:.2f}s"
        )
