"""
State Encoder for Risk-Aware Optical Network Provisioning

This module implements the original comprehensive state encoder that
extracts rich features from the network state, service request, and
candidate paths.

The encoder produces a high-dimensional observation vector suitable
for deep RL agents. For very large networks, consider using the GNN
encoder (gnn_encoder.py) to handle scalability.
"""
import numpy as np
from typing import List, Dict, Tuple, Optional, Callable
from dataclasses import dataclass

# Import utility functions
from utils.spectrum import (
    compute_spectrum_fragmentation,
    compute_largest_free_block,
    compute_spectrum_utilization,
    compute_spectrum_entropy
)
from utils.criticality import compute_path_risk_exposure
from utils.qot import Modulation


@dataclass
class EncoderConfig:
    """
    Configuration for the state encoder.
    
    Attributes:
        num_nodes: Number of nodes in the network
        bands: List of band indices (e.g., [0, 1, 2] for C/L/S)
        K: Number of K-shortest paths
        H_max: Maximum hops for path encoding (padding length)
        num_mods: Number of modulation formats
        delta_norm_db: Normalization constant for QoT margin (dB)
        
    Feature Dimensions:
        - Request: num_nodes + num_nodes + 2  (src/dst one-hot + bitrate + weight)
        - Per-link: num_links * num_bands * 5  (util, frag, largest, entropy, avail)
        - Per-path: K * num_bands * 8  (hops, dist, residual, lcb, eta, delta, overlap_avg, overlap_max)
        - Criticality: K * 3  (mean, max, high_risk_fraction)
        
    Total: O(num_nodes + num_links*num_bands + K*num_bands)
    """
    num_nodes: int
    bands: List[int]
    K: int
    H_max: int
    num_mods: int
    delta_norm_db: float = 10.0
    
    # Optional: service class weights
    weight_by_class: Optional[Dict[int, float]] = None
    
    # Normalization parameters
    free_blocks_norm_cap: int = 50
    highrisk_q: float = 0.10  # Top 10% links are high-risk


class StateEncoder:
    """
    Comprehensive state encoder for optical network RL.
    
    This encoder extracts multi-level features:
    1. Request-level: source, destination, bitrate, service class
    2. Link-level: per-link spectrum state across all bands
    3. Path-level: topology, QoT, and spectrum features per candidate path
    4. Risk-level: criticality metrics for each candidate path
    
    The encoded observation can be fed directly to MLPs or other
    deep learning architectures.
    
    For very large networks (>100 nodes, >1000 links), consider using
    GNNEncoder instead to leverage graph structure.
    """
    
    def __init__(self,
                 cfg: EncoderConfig,
                 num_links: int,
                 edge_criticality: np.ndarray,
                 qot_provider,
                 slots_needed_fn: Callable[[float, Modulation, int], int]):
        """
        Initialize state encoder.
        
        Args:
            cfg: Encoder configuration
            num_links: Total number of directed links
            edge_criticality: [num_links] array of criticality values ∈ [0,1]
            qot_provider: QoT provider with methods:
                         - feasible_mods(path_id, band, bitrate) -> List[Modulation]
                         - best_mod(path_id, band, bitrate) -> Modulation
                         - margin_db(path_id, band, modulation) -> float
            slots_needed_fn: Function to compute required slots
                            (bitrate, modulation, band) -> int
        """
        self.cfg = cfg
        self.num_links = num_links
        self.edge_criticality = edge_criticality.astype(np.float32)
        self.qot = qot_provider
        self.slots_needed_fn = slots_needed_fn
        self.num_bands = len(cfg.bands)
        
        # Compute high-risk threshold (top-q% of links)
        q = float(np.clip(cfg.highrisk_q, 0.0, 1.0))
        if len(self.edge_criticality) > 0 and q > 0.0:
            self._highrisk_threshold = float(np.quantile(self.edge_criticality, 1.0 - q))
        else:
            self._highrisk_threshold = 1.0
    
    def obs_dim(self) -> int:
        """
        Calculate total observation dimension.
        
        Returns:
            Total number of features in observation vector
            
        Breakdown:
            1. Request features: 2*num_nodes + 2
            2. Per-link features: num_links * num_bands * 5
            3. Per-path features: K * num_bands * 8
            4. Criticality features: K * 3
        """
        # 1. Request: src one-hot + dst one-hot + (bitrate, weight)
        req_dim = self.cfg.num_nodes + self.cfg.num_nodes + 2
        
        # 2. Per-link spectrum features: for each band and each link
        # Features: utilization, fragmentation, largest_block, entropy, availability
        link_feat_dim = 5
        per_link_dim = self.num_bands * self.num_links * link_feat_dim
        
        # 3. Candidate-path features per (k, band):
        # Features: hops_norm, dist_norm, min_free_frac, lcb_frac, 
        #           eta_norm, delta_norm, overlap_avg, overlap_max
        cand_feat_dim = 8
        cand_dim = self.cfg.K * self.num_bands * cand_feat_dim
        
        # 4. Path criticality per k:
        # Features: mean_criticality, max_criticality, highrisk_fraction
        crit_dim = self.cfg.K * 3
        
        return req_dim + per_link_dim + cand_dim + crit_dim
    
    def encode(self,
               service,
               paths: List,
               occ_by_band_by_link: Dict[int, List[np.ndarray]],
               path_to_link_ids_fn: Callable) -> Tuple[np.ndarray, np.ndarray]:
        """
        Encode current state into observation vector and action mask.
        
        Args:
            service: Current service request with attributes:
                    - source_id, destination_id: node indices
                    - bit_rate: requested bitrate (Gbps)
                    - service_class: optional service class
            paths: List of candidate Path objects (up to K paths)
            occ_by_band_by_link: Dict {band_idx: [link_occ_arrays]}
                                where each occ array is [num_slots] with 1=occupied
            path_to_link_ids_fn: Function to get link IDs from path
            
        Returns:
            obs: Observation vector of shape [obs_dim]
            mask: Action mask of shape [K * num_bands] with 1=feasible
            
        Note:
            The observation contains:
            - Request features (who, what)
            - Global network state (per-link spectrum across all bands)
            - Local candidate features (per-path, per-band)
            - Risk features (criticality metrics)
        """
        # =================================================================
        # PART 1: REQUEST FEATURES
        # =================================================================
        parts: List[np.ndarray] = []
        
        # Source and destination one-hot encoding
        src_id = int(service.source_id)
        dst_id = int(service.destination_id)
        
        src_onehot = np.zeros(self.cfg.num_nodes, dtype=np.float32)
        dst_onehot = np.zeros(self.cfg.num_nodes, dtype=np.float32)
        
        if 0 <= src_id < self.cfg.num_nodes:
            src_onehot[src_id] = 1.0
        if 0 <= dst_id < self.cfg.num_nodes:
            dst_onehot[dst_id] = 1.0
        
        # Bitrate and service weight
        # TODO: normalize bitrate if needed
        bitrate = float(service.bit_rate)
        weight = self._get_service_weight(service)
        
        parts.append(src_onehot)
        parts.append(dst_onehot)
        parts.append(np.array([bitrate, weight], dtype=np.float32))
        
        # =================================================================
        # PART 2: PER-LINK SPECTRUM FEATURES
        # =================================================================
        # For each band, for each link, compute spectrum state features
        # This gives a global view of network resource availability
        
        # First, determine required width per band for this request
        # (minimum slots among all feasible paths in each band)
        width_req_by_band = self._compute_required_widths(paths, bitrate)
        
        link_features: List[np.ndarray] = []
        
        for band_idx in self.cfg.bands:
            occ_list_band = occ_by_band_by_link[band_idx]
            req_width = width_req_by_band[band_idx]
            
            for link_id in range(self.num_links):
                # Extract 5 features for this link
                link_feat = self._extract_link_features(
                    occ=occ_list_band[link_id],
                    req_width=req_width
                )
                link_features.append(link_feat)
        
        parts.append(np.concatenate(link_features))
        
        # =================================================================
        # PART 3: CANDIDATE PATH FEATURES + ACTION MASK
        # =================================================================
        # For each (path, band) combination, compute:
        # - Topology features (hops, distance)
        # - Spectrum features (residual capacity, fragmentation)
        # - QoT features (modulation flexibility, margin)
        # - Diversity features (overlap with other paths)
        
        mask = np.zeros(self.cfg.K * self.num_bands, dtype=np.float32)
        cand_features: List[float] = []
        crit_features: List[float] = []
        
        # Pre-compute path link IDs and overlap statistics
        # FIXED: Pass Path object instead of node_list
        paths_link_ids = [
            path_to_link_ids_fn(path) if k < len(paths) else []
            for k, path in enumerate(paths[:self.cfg.K])
        ]
        
        overlap_stats = self._compute_path_overlap(paths_link_ids)
        
        # Normalization constants
        # TODO: adjust based on network size and automated analysis
        dist_norm_scale = 5000.0  # Typical max distance in km
        
        # Process each candidate path
        for k in range(self.cfg.K):
            if k < len(paths):
                path = paths[k]
                link_ids_k = paths_link_ids[k]
                node_list_k = path.node_list
            else:
                # Padding for missing paths
                link_ids_k = []
                node_list_k = []
            
            # --- Criticality features for this path ---
            if len(link_ids_k) != 0:
                risk_metrics = compute_path_risk_exposure(
                    np.array(link_ids_k),
                    self.edge_criticality,
                    self._highrisk_threshold
                )
                mean_crit = risk_metrics['mean_criticality']
                max_crit = risk_metrics['max_criticality']
                highrisk_frac = risk_metrics['high_risk_fraction']
            else:
                mean_crit = max_crit = highrisk_frac = 0.0
            
            crit_features.extend([mean_crit, max_crit, highrisk_frac])
            
            # --- Per-band features for this path ---
            for band_idx_enum, band_idx in enumerate(self.cfg.bands):
                action_idx = k * self.num_bands + band_idx_enum
                
                if k >= len(paths) or len(link_ids_k) == 0:
                    # No path available: zero features, invalid action
                    cand_features.extend([0.0] * 8)
                    mask[action_idx] = 0.0
                    continue
                
                # ----- Topology features -----
                hops = float(max(0, len(node_list_k) - 1))
                hops_norm = float(np.clip(hops / max(1.0, self.cfg.num_nodes - 1), 0.0, 1.0))
                
                distance_km = float(path.length)
                dist_norm = float(np.clip(distance_km / dist_norm_scale, 0.0, 1.0))
                
                # ----- Spectrum availability features -----
                occ_list = [occ_by_band_by_link[band_idx][lid] for lid in link_ids_k]
                
                # Minimum residual capacity across links
                free_fracs = [float(np.mean(occ == 0)) for occ in occ_list]
                min_free_frac = float(min(free_fracs)) if free_fracs else 0.0
                
                # Largest common free block (normalized)
                lcb = compute_largest_free_block(occ_list)
                lcb_norm = float(lcb) / float(max(1, len(occ_list[0])))
                
                # ----- QoT features -----
                path_id = int(path.path_id)
                feasible_mods = self.qot.feasible_mods(path_id, band_idx, bitrate)
                
                # Eta: modulation flexibility (fraction of mods that are feasible)
                eta_norm = float(len(feasible_mods)) / float(max(1, self.cfg.num_mods))
                
                # Delta: QoT margin for best modulation
                if len(feasible_mods) == 0:
                    delta_norm = 0.0
                else:
                    best_mod = self.qot.best_mod(path_id, band_idx, bitrate)
                    delta_db = self.qot.margin_db(path_id, band_idx, best_mod)
                    delta_norm = float(np.clip(delta_db / self.cfg.delta_norm_db, 0.0, 1.0))
                
                # ----- Diversity features -----
                overlap_avg = float(overlap_stats['avg'][k])
                overlap_max = float(overlap_stats['max'][k])
                
                # ----- Action feasibility -----
                # Action is feasible if: (1) QoT OK, (2) spectrum available
                feasible_now = (eta_norm > 0.0) and (lcb > 0)
                mask[action_idx] = 1.0 if feasible_now else 0.0
                
                # Aggregate features for this (path, band)
                cand_features.extend([
                    hops_norm,      # Topology: path length in hops
                    dist_norm,      # Topology: physical distance
                    min_free_frac,  # Spectrum: bottleneck residual capacity
                    lcb_norm,       # Spectrum: largest allocatable block
                    eta_norm,       # QoT: modulation flexibility
                    delta_norm,     # QoT: margin for best modulation
                    overlap_avg,    # Diversity: average overlap with others
                    overlap_max     # Diversity: max overlap with any other path
                ])
        
        # Add candidate and criticality features
        parts.append(np.array(cand_features, dtype=np.float32))
        parts.append(np.array(crit_features, dtype=np.float32))
        
        # =================================================================
        # FINAL: CONCATENATE ALL PARTS
        # =================================================================
        obs = np.concatenate(parts, axis=0).astype(np.float32)
        
        return obs, mask
    
    # =====================================================================
    # HELPER METHODS
    # =====================================================================
    
    def _get_service_weight(self, service) -> float:
        """Get weight for service based on class (if configured)."""
        if self.cfg.weight_by_class is None:
            return 1.0
        
        cls = int(service.service_class) if hasattr(service, 'service_class') and service.service_class is not None else 0
        return float(self.cfg.weight_by_class.get(cls, 1.0))
    
    def _compute_required_widths(self, paths: List, bitrate: float) -> Dict[int, int]:
        """
        Compute minimum required slots per band for current request.
        
        For each band, find the minimum number of slots among all
        QoT-feasible candidate paths.
        """
        width_by_band = {}
        
        for band_idx in self.cfg.bands:
            best_slots = None
            
            for k in range(min(self.cfg.K, len(paths))):
                path_id = int(paths[k].path_id)
                
                # Check QoT feasibility
                # TODO: try to fix the logic here,
                #  if use pre-computed GSNR table, each slot on this path should have the
                #  fixed highest modulation format (feasible mods are known)
                #   Also the best mod

                feasible_mods = self.qot.feasible_mods(path_id, band_idx, bitrate)
                if not feasible_mods:
                    continue
                
                # Get best modulation and compute slots
                best_mod = self.qot.best_mod(path_id, band_idx, bitrate)
                slots = int(self.slots_needed_fn(bitrate, best_mod, band_idx))
                
                # TODO: is the logic (min) here using
                best_slots = slots if best_slots is None else min(best_slots, slots)
            
            # If no feasible path, set to very large number
            width_by_band[band_idx] = int(best_slots) if best_slots is not None else int(1e9)
        
        return width_by_band
    
    def _extract_link_features(self, occ: np.ndarray, req_width: int) -> np.ndarray:
        """
        Extract 5 features for a single link's spectrum state.
        
        Features:
        1. Utilization: fraction of occupied slots
        2. Fragmentation: number of free blocks (normalized)
        3. Largest free block: size of largest contiguous free segment
        4. Entropy: randomness of occupancy pattern
        5. Availability: whether required width can fit (binary)
        
        Args:
            occ: Occupancy array [num_slots]
            req_width: Required number of contiguous slots
            
        Returns:
            Feature vector [5]
        """
        # 1. Utilization
        util = compute_spectrum_utilization(occ)
        
        # 2. Fragmentation
        frag = compute_spectrum_fragmentation(occ)
        
        # 3. Largest free block (normalized by total slots)
        largest = compute_largest_free_block([occ])
        largest_norm = float(largest) / float(max(1, len(occ)))
        
        # 4. Entropy
        entropy = compute_spectrum_entropy(occ, normalize=True)
        
        # 5. Availability (binary: can fit required width?)
        available = 1.0 if largest >= req_width else 0.0
        
        return np.array([util, frag, largest_norm, entropy, available], dtype=np.float32)
    
    def _compute_path_overlap(self, paths_link_ids: List[List[int]]) -> Dict:
        """
        Compute overlap statistics between candidate paths.
        
        Overlap = fraction of shared links between paths.
        Higher diversity (lower overlap) is often preferable.
        
        Args:
            paths_link_ids: List of link ID lists, one per path
            
        Returns:
            Dictionary with:
                'avg': [K] average overlap with all other paths
                'max': [K] maximum overlap with any other path
        """
        K = len(paths_link_ids)
        overlap_avg = np.zeros(K, dtype=np.float32)
        overlap_max = np.zeros(K, dtype=np.float32)
        
        for k in range(K):
            if len(paths_link_ids[k]) == 0:
                continue
            
            set_k = set(paths_link_ids[k])
            overlaps = []
            
            for j in range(K):
                if j == k or len(paths_link_ids[j]) == 0:
                    continue
                
                set_j = set(paths_link_ids[j])
                
                # Jaccard similarity: |intersection| / |union|
                intersection = len(set_k & set_j)
                union = len(set_k | set_j)
                
                if union > 0:
                    overlap = intersection / union
                    overlaps.append(overlap)
            
            if overlaps:
                overlap_avg[k] = np.mean(overlaps)
                overlap_max[k] = np.max(overlaps)
        
        return {'avg': overlap_avg, 'max': overlap_max}


def _path_distance_km(path) -> float:
    """Extract distance in km from Path object."""
    return float(getattr(path, 'length', 0.0))
