"""
Configuration Management for Risk-Aware Optical Network Provisioning

This module provides centralized configuration using Python dataclasses.
All hyperparameters and settings are organized into logical groups.
"""
from dataclasses import dataclass
from typing import List, Dict, Optional
import numpy as np


@dataclass
class NetworkConfig:
    """
    Network topology configuration.

    Attributes:
        topology_name: Name of the network (e.g., "USNET", "NSFNET")
        topology_path: Path to topology Excel file
        k_paths: Number of K-shortest paths to compute
        bands: List of frequency band names (e.g., ['C', 'L', 'S'])
        slots_per_band: Number of frequency slots per band
        slot_bandwidth_ghz: Bandwidth of each slot in GHz
        guard_band_slots: Number of guard band slots between channels

        # NEW: GSNR data for advanced QoT
        gsnr_data_path: Path to precomputed GSNR pickle file (None = use simple QoT)
        gsnr_channel_spacing_ghz: Channel spacing in GSNR data (default 50 GHz)
    """
    topology_name: str = "US24"
    topology_path: str = f"config_files/topo_{topology_name.lower()}_txOnly.xlsx"
    k_paths: int = 5

    # Spectrum parameters
    bands: List[str] = None
    slots_per_band: int = 400
    slot_bandwidth_ghz: float = 12.5
    guard_band_slots: int = 1

    # GSNR QoT parameters (NEW)
    gsnr_data_path: Optional[str] = None  # Set to enable GSNR-based QoT
    gsnr_channel_spacing_ghz: float = 50.0  # GSNR data channel spacing

    def __post_init__(self):
        """Set default values for mutable defaults."""
        if self.bands is None:
            self.bands = ['C', 'L', 'S']

@dataclass
class TrafficConfig:
    """
    Traffic generation configuration.
    
    Attributes:
        mean_service_holding_time: Mean holding time in seconds
        mean_service_inter_arrival_time: Mean inter-arrival time in seconds
        bit_rates: List of possible bitrates in Gbps
        bit_rate_probabilities: Probability distribution over bitrates
                               (None = uniform distribution)
    """
    mean_service_holding_time: float = 900.0  # 15 minutes
    mean_service_inter_arrival_time: float = 1.0  # 1 second
    bit_rates: List[int] = None
    bit_rate_probabilities: List[float] = None
    
    def __post_init__(self):
        """Set default bitrates and probabilities."""
        if self.bit_rates is None:
            self.bit_rates = [100, 200, 400]
        
        if self.bit_rate_probabilities is None:
            # Uniform distribution
            self.bit_rate_probabilities = [1.0/len(self.bit_rates)] * len(self.bit_rates)
    
    def get_load(self) -> float:
        """
        Calculate offered load in Erlangs.
        
        Load = mean_holding_time / mean_inter_arrival_time
        """
        return self.mean_service_holding_time / self.mean_service_inter_arrival_time


@dataclass
class EnvConfig:
    """
    Environment configuration.
    
    Attributes:
        episode_length: Number of service requests per episode
        use_mask: Whether to use action masking
        encoder_type: Type of encoder ('original' or 'gnn')
        
        # Criticality parameters
        criticality_method: How to compute criticality
                           ('betweenness', 'traffic', or 'combined')
        highrisk_quantile: Quantile threshold for high-risk links (e.g., 0.90 = top 10%)

        
        # Encoder parameters
        use_original_encoder: If True, use comprehensive encoder; if False, use GNN
        gnn_embedding_dim: Embedding dimension for GNN encoder
        
        # Normalization
        normalize_observations: Whether to normalize observations
    """
    episode_length: int = 1000
    use_mask: bool = True
    
    # Criticality
    criticality_method: str = 'betweenness'
    highrisk_quantile: float = 0.10

    # NEW: Reward configuration
    reward_scheme: str = 'bitrate_weighted'  # 'uniform', 'bitrate_weighted', 'bitrate_criticality'
    reward_accept_base: float = 1.0
    reward_block_base: float = -1.0
    # Keep consistency with the bitrate setting in traffic config
    bitrate_normalization: float = 400.0  # Normalize by 400 Gbps
    criticality_penalty_weight: float = 0.0  # Weight for criticality penalty
    
    # # Rewards
    # accept_reward: float = 1.0
    # block_penalty: float = -1.0
    # criticality_penalty_weight: float = 0.0
    
    # Encoder
    use_original_encoder: bool = True
    gnn_embedding_dim: int = 64
    
    # Normalization
    normalize_observations: bool = True


@dataclass
class TrainingConfig:
    """
    Training configuration for PPO.
    
    Attributes:
        # Parallelization
        n_envs: Number of parallel environments
        
        # Training steps
        total_timesteps: Total training timesteps
        
        # PPO hyperparameters
        learning_rate: Learning rate
        n_steps: Steps per environment before update
        batch_size: Minibatch size for training
        n_epochs: Number of epochs per update
        gamma: Discount factor
        gae_lambda: GAE lambda parameter
        clip_range: PPO clipping parameter
        ent_coef: Entropy coefficient
        vf_coef: Value function coefficient
        max_grad_norm: Maximum gradient norm
        
        # Network architecture
        net_arch: Network architecture for actor and critic
                 Format: [dict(pi=[...], vf=[...])]
        activation_fn: Activation function name ('relu', 'tanh')
        
        # Logging and saving
        log_dir: Directory for logs and checkpoints
        checkpoint_freq: Save checkpoint every N steps
        eval_freq: Evaluate every N steps
        n_eval_episodes: Number of episodes for evaluation
        
        # Device
        device: 'cpu', 'cuda', or 'auto'
        seed: Random seed
    """
    # Parallelization
    n_envs: int = 5
    
    # Training
    total_timesteps: int = 1_000_000
    
    # PPO parameters
    learning_rate: float = 3e-4
    n_steps: int = 2048
    batch_size: int = 64
    n_epochs: int = 10
    gamma: float = 0.99
    gae_lambda: float = 0.95
    clip_range: float = 0.2
    ent_coef: float = 0.0
    vf_coef: float = 0.5
    max_grad_norm: float = 0.5
    
    # Network architecture
    net_arch: List[Dict] = None
    activation_fn: str = 'relu'

    # NEW: CVaR configuration
    use_cvar: bool = False  # Whether to use CVaR-PPO
    cvar_alpha: float = 0.1  # Risk level (0.1 = worst 10%)
    cvar_weight: float = 0.5  # CVaR vs mean weight (0=mean, 1=CVaR)
    
    # Logging
    log_dir: str = "./logs/"
    save_freq: int = 10000
    eval_freq: int = 5000
    n_eval_episodes: int = 10
    
    # Device
    device: str = "auto"
    seed: int = 42
    
    def __post_init__(self):
        """Set default network architecture."""
        if self.net_arch is None:
            self.net_arch = [dict(pi=[256, 256], vf=[256, 256])]


@dataclass
class ModulationConfig:
    """
    Modulation format configuration.
    
    By default, uses standard modulation formats.
    Can be customized for specific system requirements.
    """
    # Modulation formats are defined in utils/qot.py
    # This config just stores which modulations to use
    use_default_modulations: bool = True
    
    # If use_default_modulations=False, specify custom formats here
    custom_modulations: Optional[List] = None


def get_default_config() -> Dict:
    """
    Get default configuration for all components.
    
    Returns:
        Dictionary with all configuration objects:
        - 'network': NetworkConfig
        - 'traffic': TrafficConfig
        - 'env': EnvConfig
        - 'training': TrainingConfig
        - 'modulation': ModulationConfig
    """
    return {
        'network': NetworkConfig(),
        'traffic': TrafficConfig(),
        'env': EnvConfig(),
        'training': TrainingConfig(),
        'modulation': ModulationConfig()
    }


def print_config(config: Dict):
    """
    Print configuration in a readable format.
    
    Args:
        config: Configuration dictionary from get_default_config()
    """
    print("=" * 70)
    print("CONFIGURATION")
    print("=" * 70)
    
    for category, cfg in config.items():
        print(f"\n{category.upper()}:")
        print("-" * 70)
        
        for key, value in cfg.__dict__.items():
            if not key.startswith('_'):
                # Format value for display
                if isinstance(value, float):
                    print(f"  {key:.<40} {value:.6f}")
                elif isinstance(value, (list, dict)) and len(str(value)) > 50:
                    print(f"  {key:.<40} {type(value).__name__}")
                else:
                    print(f"  {key:.<40} {value}")
    
    print("=" * 70)


def save_config(config: Dict, filepath: str):
    """
    Save configuration to JSON file.
    
    Args:
        config: Configuration dictionary
        filepath: Path to save JSON file
    """
    import json
    
    # Convert dataclasses to dictionaries
    config_dict = {}
    for category, cfg in config.items():
        config_dict[category] = {
            k: str(v) if not isinstance(v, (int, float, bool, str, list, dict, type(None)))
            else v
            for k, v in cfg.__dict__.items()
            if not k.startswith('_')
        }
    
    with open(filepath, 'w') as f:
        json.dump(config_dict, f, indent=2)
    
    print(f"Configuration saved to {filepath}")


def load_config(filepath: str) -> Dict:
    """
    Load configuration from JSON file.
    
    Args:
        filepath: Path to JSON file
        
    Returns:
        Configuration dictionary
        
    Note:
        This creates new config objects with values from JSON.
        Some complex types may need manual reconstruction.
    """
    import json
    
    with open(filepath, 'r') as f:
        config_dict = json.load(f)
    
    # Reconstruct dataclass objects
    config = {
        'network': NetworkConfig(**config_dict.get('network', {})),
        'traffic': TrafficConfig(**config_dict.get('traffic', {})),
        'env': EnvConfig(**config_dict.get('env', {})),
        'training': TrainingConfig(**config_dict.get('training', {})),
        'modulation': ModulationConfig(**config_dict.get('modulation', {}))
    }
    
    print(f"Configuration loaded from {filepath}")
    return config


# Example usage
if __name__ == "__main__":
    def get_uniform_reward_config():
        """Standard uniform reward (+1/-1)."""
        config = get_default_config()
        config['env'].reward_scheme = 'uniform'
        config['env'].reward_accept_base = 1.0
        config['env'].reward_block_base = -1.0
        return config


    def get_bitrate_weighted_config():
        """Bit-rate weighted reward."""
        config = get_default_config()
        config['env'].reward_scheme = 'bitrate_weighted'
        config['env'].reward_accept_base = 1.0
        config['env'].reward_block_base = -1.0
        config['env'].bitrate_normalization = max(config['traffic'].bit_rates)  # Normalize by max bitrate
        return config


    def get_cvar_config(alpha: float = 0.1, weight: float = 0.5):
        """CVaR-optimized configuration."""
        config = get_bitrate_weighted_config()  # Use bitrate weighting
        config['training'].use_cvar = True
        config['training'].cvar_alpha = alpha
        config['training'].cvar_weight = weight
        return config


    # Get default configuration
    config = get_default_config()

    topology_name = 'BTUK'
    config['network'].topology_name = topology_name
    config['network'].topology_path = f"config_files/topo_{topology_name.lower()}_txOnly.xlsx"
    config['network'].gsnr_data_path = f"config_files/{topology_name.lower()}_roadm_all_pairs_ksp_gsnr.pkl"
    # Will automatically use GSNRQoTProvider
    
    # Print it
    print_config(config)
    
    # Modify some values
    config['training'].total_timesteps = 500_000
    config['training'].n_envs = 8
    config['network'].k_paths = 3
    
    print("\nModified configuration:")
    print_config(config)
    
    # # Save to file
    # save_config(config, 'my_config.json')
    #
    # # Load from file
    # loaded_config = load_config('my_config.json')

    # # Example 3: Custom GSNR with different channel spacing
    # config = get_default_config()
    # config['network'].gsnr_data_path = "gsnr_data/custom_gsnr.pkl"
    # config['network'].gsnr_channel_spacing_ghz = 75.0  # If using 75 GHz spacing
    # # Slots per channel = 75 / 12.5 = 6 slots

    print("=" * 70)
    print("REWARD CONFIGURATION EXAMPLES")
    print("=" * 70)

    # Example 1: Uniform reward (original)
    print("\n1. Uniform Reward (Original):")
    print("   Accept 100 Gbps: +1")
    print("   Block 100 Gbps:  -1")
    print("   Accept 400 Gbps: +1")
    print("   Block 400 Gbps:  -1")

    # Example 2: Bit-rate weighted
    print("\n2. Bit-Rate Weighted (norm=400):")
    print("   Accept 100 Gbps: +(100/400) = +0.1")
    print("   Block 100 Gbps:  -(100/400) = -0.1")
    print("   Accept 200 Gbps: +(200/400) = +0.2")
    print("   Block 200 Gbps:  -(200/400) = -0.2")
    print("   → Higher bitrate services have more impact!")

    # Example 3: CVaR optimization
    print("\n3. CVaR Optimization (α=0.1):")
    print("   Focus on worst 10% of episodes")
    print("   Optimize: E[return | return ≤ VaR_0.1]")
    print("   → Risk-sensitive, robust to worst cases")

    print("\n" + "=" * 70)



