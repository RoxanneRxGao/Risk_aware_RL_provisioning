"""
Models Package for Risk-Aware RL Provisioning

This package contains:
- CVaRPPO: Risk-sensitive PPO using Conditional Value-at-Risk
- CVaRMaskablePPO: Risk-sensitive MaskablePPO with action masking
- GNN Encoder: Graph Neural Network for state encoding
"""

from .cvar_ppo import CVaRPPO, CVaRCallback, compute_cvar_from_rewards

# Try to import CVaRMaskablePPO (requires sb3-contrib)
try:
    from .cvar_maskable_ppo import (
        CVaRMaskablePPO,
        CVaRMaskableCallback,
        compute_cvar_from_rewards as compute_cvar_maskable
    )
    MASKABLE_AVAILABLE = True
except ImportError:
    MASKABLE_AVAILABLE = False
    CVaRMaskablePPO = None
    CVaRMaskableCallback = None

# Try to import GNN encoder
try:
    from .gnn_encoder import GNNStateEncoder
    GNN_AVAILABLE = True
except ImportError:
    GNN_AVAILABLE = False
    GNNStateEncoder = None

__all__ = [
    'CVaRPPO',
    'CVaRCallback',
    'CVaRMaskablePPO',
    'CVaRMaskableCallback',
    'GNNStateEncoder',
    'compute_cvar_from_rewards',
    'MASKABLE_AVAILABLE',
    'GNN_AVAILABLE',
]
