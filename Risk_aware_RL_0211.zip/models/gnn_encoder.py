"""
Graph Neural Network (GNN) State Encoder

This encoder is designed for large-scale networks where the observation
space would explode with the standard encoder.

Instead of explicitly encoding all links and paths, the GNN encoder:
1. Represents the network as a graph
2. Uses message passing to aggregate information
3. Produces compact node/edge embeddings
4. Combines with request and path features

Scalability:
- Standard encoder: O(num_links * num_bands) features
- GNN encoder: O(embedding_dim) features (constant!)

Recommended for networks with:
- More than 50 nodes
- More than 200 links
- Complex topology structures
"""
import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
from typing import List, Dict, Tuple, Optional

try:
    import torch_geometric
    from torch_geometric.nn import GCNConv, GATConv, global_mean_pool
    from torch_geometric.data import Data, Batch
    GNN_AVAILABLE = True
except ImportError:
    GNN_AVAILABLE = False
    print("Warning: torch_geometric not installed. GNN encoder will not work.")
    print("Install with: pip install torch-geometric")


class GNNStateEncoder(nn.Module):
    """
    GNN-based state encoder for scalable network representation.
    
    Architecture:
    1. Node features: criticality, degree, location (if available)
    2. Edge features: spectrum utilization, fragmentation, capacity
    3. Graph convolution layers to aggregate neighborhood information
    4. Global pooling to get network-level representation
    5. Combine with request features and candidate path features
    
    The final observation is a fixed-size vector regardless of network size!
    """
    
    def __init__(self,
                 num_nodes: int,
                 num_bands: int,
                 embedding_dim: int = 64,
                 num_gnn_layers: int = 3,
                 gnn_type: str = 'GCN',
                 include_edge_features: bool = True):
        """
        Initialize GNN encoder.
        
        Args:
            num_nodes: Number of nodes in the network
            num_bands: Number of frequency bands
            embedding_dim: Dimension of node/edge embeddings
            num_gnn_layers: Number of GNN layers (depth)
            gnn_type: Type of GNN ('GCN', 'GAT', or 'GraphSAGE')
            include_edge_features: Whether to use edge features
        """
        super().__init__()
        
        if not GNN_AVAILABLE:
            raise ImportError("torch_geometric is required for GNN encoder")
        
        self.num_nodes = num_nodes
        self.num_bands = num_bands
        self.embedding_dim = embedding_dim
        self.num_gnn_layers = num_gnn_layers
        self.include_edge_features = include_edge_features
        
        # Node feature dimensions:
        # - Criticality: 1
        # - Degree: 1
        # - One-hot encoding: num_nodes (optional, for small networks)
        # - Additional: can add coordinates if available
        self.node_feat_dim = 2  # criticality + degree
        
        # Edge feature dimensions (per band):
        # - Utilization: 1
        # - Fragmentation: 1
        # - Largest free block: 1
        # - Total per edge: 3 * num_bands
        self.edge_feat_dim = 3 * num_bands if include_edge_features else 0
        
        # Input projection layers
        self.node_encoder = nn.Linear(self.node_feat_dim, embedding_dim)
        if include_edge_features:
            self.edge_encoder = nn.Linear(self.edge_feat_dim, embedding_dim)
        
        # GNN layers
        self.gnn_layers = nn.ModuleList()
        for _ in range(num_gnn_layers):
            if gnn_type == 'GCN':
                self.gnn_layers.append(GCNConv(embedding_dim, embedding_dim))
            elif gnn_type == 'GAT':
                self.gnn_layers.append(GATConv(embedding_dim, embedding_dim, heads=4, concat=False))
            else:
                raise ValueError(f"Unknown GNN type: {gnn_type}")
        
        # Request encoder
        # Features: src_id, dst_id, bitrate, weight
        self.request_encoder = nn.Sequential(
            nn.Linear(4, embedding_dim),
            nn.ReLU(),
            nn.Linear(embedding_dim, embedding_dim)
        )
        
        # Path encoder (per candidate path)
        # Features: hops, distance, criticality, num_feasible_bands
        self.path_encoder = nn.Sequential(
            nn.Linear(4, embedding_dim),
            nn.ReLU(),
            nn.Linear(embedding_dim, embedding_dim)
        )
        
        # Final aggregation
        # Combines: graph embedding + request embedding + path embeddings
        self.output_dim = embedding_dim * 3  # graph + request + max_pool(paths)
    
    def forward(self,
                graph_data,
                request_features: torch.Tensor,
                path_features: torch.Tensor) -> torch.Tensor:
        """
        Forward pass through GNN encoder.
        
        Args:
            graph_data: PyG Data object with:
                       - x: node features [num_nodes, node_feat_dim]
                       - edge_index: [2, num_edges]
                       - edge_attr: edge features [num_edges, edge_feat_dim]
            request_features: [4] tensor (src_id, dst_id, bitrate, weight)
            path_features: [K, 4] tensor (per-path features)
            
        Returns:
            Encoded state vector [output_dim]
        """
        # Encode nodes
        x = self.node_encoder(graph_data.x)
        edge_index = graph_data.edge_index
        
        # Message passing through GNN layers
        for gnn_layer in self.gnn_layers:
            x = gnn_layer(x, edge_index)
            x = F.relu(x)
        
        # Global pooling to get graph-level representation
        graph_embedding = torch.mean(x, dim=0)  # [embedding_dim]
        
        # Encode request
        request_embedding = self.request_encoder(request_features)  # [embedding_dim]
        
        # Encode paths and aggregate
        if len(path_features) > 0:
            path_embeddings = self.path_encoder(path_features)  # [K, embedding_dim]
            path_embedding = torch.max(path_embeddings, dim=0)[0]  # [embedding_dim]
        else:
            path_embedding = torch.zeros(self.embedding_dim)
        
        # Concatenate all components
        full_embedding = torch.cat([
            graph_embedding,
            request_embedding,
            path_embedding
        ], dim=0)
        
        return full_embedding
    
    def get_output_dim(self) -> int:
        """Return dimension of output embedding."""
        return self.output_dim


class GNNEncoderWrapper:
    """
    Wrapper to convert network state to GNN-compatible format.
    
    This class handles the conversion from raw network state
    (spectrum occupancy, paths, service) to PyTorch Geometric
    format required by the GNN encoder.
    """
    
    def __init__(self,
                 topology,
                 num_bands: int,
                 edge_criticality: np.ndarray,
                 embedding_dim: int = 64,
                 device: str = 'cpu'):
        """
        Initialize GNN encoder wrapper.
        
        Args:
            topology: NetworkX graph
            num_bands: Number of frequency bands
            edge_criticality: [num_links] criticality values
            embedding_dim: GNN embedding dimension
            device: 'cpu' or 'cuda'
        """
        self.topology = topology
        self.num_nodes = topology.number_of_nodes()
        self.num_edges = topology.number_of_edges()
        self.num_bands = num_bands
        self.edge_criticality = edge_criticality
        self.device = device
        
        # Create GNN model
        self.gnn = GNNStateEncoder(
            num_nodes=self.num_nodes,
            num_bands=num_bands,
            embedding_dim=embedding_dim
        ).to(device)
        
        # Build static graph structure (edge_index)
        self.edge_index = self._build_edge_index()
        
        # Node degrees (static)
        self.node_degrees = self._compute_node_degrees()
    
    def _build_edge_index(self) -> torch.Tensor:
        """
        Build edge index tensor from NetworkX graph.
        
        Returns:
            [2, num_edges] tensor
        """
        edges = []
        for u, v in self.topology.edges():
            u_idx = self.topology.nodes[u]['index']
            v_idx = self.topology.nodes[v]['index']
            edges.append([u_idx, v_idx])
            edges.append([v_idx, u_idx])  # Add reverse edge
        
        edge_index = torch.tensor(edges, dtype=torch.long).t().contiguous()
        return edge_index.to(self.device)
    
    def _compute_node_degrees(self) -> np.ndarray:
        """Compute node degrees."""
        degrees = np.array([self.topology.degree(node) for node in self.topology.nodes()])
        return degrees / degrees.max()  # Normalize
    
    def encode(self,
               service,
               paths: List,
               occ_by_band_by_link: Dict,
               path_to_link_ids_fn) -> Tuple[np.ndarray, np.ndarray]:
        """
        Encode state using GNN.
        
        Args:
            service: Service request
            paths: Candidate paths
            occ_by_band_by_link: Spectrum occupancy
            path_to_link_ids_fn: Function to get link IDs
            
        Returns:
            obs: Observation vector
            mask: Action mask
        """
        # Build graph data
        graph_data = self._build_graph_data(occ_by_band_by_link)
        
        # Build request features
        request_feat = self._build_request_features(service)
        
        # Build path features and mask
        path_feat, mask = self._build_path_features(
            paths, service, occ_by_band_by_link, path_to_link_ids_fn
        )
        
        # Forward pass through GNN
        with torch.no_grad():
            obs = self.gnn(graph_data, request_feat, path_feat)
        
        return obs.cpu().numpy(), mask
    
    def _build_graph_data(self, occ_by_band_by_link: Dict):
        """Build PyG Data object from current network state."""
        # Node features: [num_nodes, 2] (criticality, degree)
        # Here we use average criticality of adjacent edges
        node_crit = np.zeros(self.num_nodes)
        for node in self.topology.nodes():
            node_idx = self.topology.nodes[node]['index']
            adjacent_edges = [
                self.topology[node][neighbor]['index']
                for neighbor in self.topology.neighbors(node)
            ]
            if adjacent_edges:
                node_crit[node_idx] = np.mean(self.edge_criticality[adjacent_edges])
        
        node_features = np.column_stack([node_crit, self.node_degrees])
        x = torch.tensor(node_features, dtype=torch.float32).to(self.device)
        
        # Edge features: [num_edges, 3*num_bands]
        # For each edge, for each band: util, frag, largest
        edge_features = []
        for u, v in self.topology.edges():
            edge_idx = self.topology[u][v]['index']
            edge_feat = []
            
            for band in range(self.num_bands):
                occ = occ_by_band_by_link[band][edge_idx]
                util = np.mean(occ)
                
                # Simple fragmentation metric
                frag = len([1 for i in range(len(occ)-1) if occ[i] != occ[i+1]]) / len(occ)
                
                # Largest free block
                max_free = 0
                current = 0
                for slot in occ:
                    if slot == 0:
                        current += 1
                        max_free = max(max_free, current)
                    else:
                        current = 0
                largest_norm = max_free / len(occ)
                
                edge_feat.extend([util, frag, largest_norm])
            
            edge_features.append(edge_feat)
            edge_features.append(edge_feat)  # Duplicate for reverse edge
        
        edge_attr = torch.tensor(edge_features, dtype=torch.float32).to(self.device)
        
        return Data(x=x, edge_index=self.edge_index, edge_attr=edge_attr)
    
    def _build_request_features(self, service) -> torch.Tensor:
        """Build request feature vector [4]."""
        return torch.tensor([
            float(service.source_id) / self.num_nodes,
            float(service.destination_id) / self.num_nodes,
            float(service.bit_rate) / 1000.0,
            1.0  # weight
        ], dtype=torch.float32).to(self.device)
    
    def _build_path_features(self, paths, service, occ_by_band_by_link, path_to_link_ids_fn):
        """Build path features and action mask."""
        path_feats = []
        mask = []
        
        K = len(paths)
        
        for path in paths:
            link_ids = path_to_link_ids_fn(path.node_list)
            
            # Path features
            hops_norm = len(link_ids) / self.num_nodes
            dist_norm = path.length / 5000.0
            path_crit = np.mean(self.edge_criticality[link_ids]) if len(link_ids) > 0 else 0.0
            
            # Count feasible bands
            num_feasible = 0
            for band in range(self.num_bands):
                occ_list = [occ_by_band_by_link[band][lid] for lid in link_ids]
                # Simple check: any free slots?
                if any(np.any(occ == 0) for occ in occ_list):
                    num_feasible += 1
                    mask.append(1.0)
                else:
                    mask.append(0.0)
            
            num_feasible_norm = num_feasible / self.num_bands
            
            path_feats.append([hops_norm, dist_norm, path_crit, num_feasible_norm])
        
        path_feat_tensor = torch.tensor(path_feats, dtype=torch.float32).to(self.device)
        mask_array = np.array(mask, dtype=np.float32)
        
        return path_feat_tensor, mask_array
    
    def obs_dim(self) -> int:
        """Return observation dimension."""
        return self.gnn.get_output_dim()
