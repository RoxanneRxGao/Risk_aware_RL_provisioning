import numpy as np
from typing import List, Tuple

from sb3_contrib import MaskablePPO


class CVaRMaskablePPO(MaskablePPO):
    def __init__(self, *args, alpha: float = 0.1, cvar_weight: float = 0.5, non_tail_weight: float = 0.1, **kwargs):
        super().__init__(*args, **kwargs)
        self.alpha = float(alpha)
        self.cvar_weight = float(cvar_weight)
        self.non_tail_weight = float(non_tail_weight)

    def _segment_rollout_by_episodes(self, buffer) -> Tuple[List[Tuple[int,int,int]], np.ndarray]:
        """
        Returns:
          segments: list of (env_idx, start_t, end_t) over buffer steps
          returns:  array of segment returns aligned with segments
        """
        rewards = buffer.rewards               # (T, n_envs)
        starts  = buffer.episode_starts        # (T, n_envs)

        T, n_envs = rewards.shape
        segments: List[Tuple[int,int,int]] = []
        seg_returns: List[float] = []

        for e in range(n_envs):
            seg_start = 0
            seg_sum = 0.0
            for t in range(T):
                if starts[t, e] and t != seg_start:
                    segments.append((e, seg_start, t))
                    seg_returns.append(float(seg_sum))
                    seg_start = t
                    seg_sum = 0.0
                seg_sum += float(rewards[t, e])

            if seg_start != T:
                segments.append((e, seg_start, T))
                seg_returns.append(float(seg_sum))

        return segments, np.asarray(seg_returns, dtype=np.float32)

    def _apply_cvar_weights(self, buffer) -> None:
        if self.cvar_weight <= 0:
            return

        segments, returns = self._segment_rollout_by_episodes(buffer)
        if returns.size == 0:
            return

        # VaR threshold for worst alpha tail
        n = returns.size
        n_tail = max(1, int(np.ceil(self.alpha * n)))
        sorted_ret = np.sort(returns)
        var_thr = float(sorted_ret[n_tail - 1])

        adv = buffer.advantages  # (T, n_envs)

        # weights:
        # tail -> 1.0
        # non-tail -> non_tail_weight (>=0)
        for (env_idx, s, t), r in zip(segments, returns):
            w = 1.0 if r <= var_thr else self.non_tail_weight
            # interpolate between mean and CVaR via cvar_weight
            # cvar_weight=0 -> w=1 for all
            # cvar_weight=1 -> w as defined above
            w = (1.0 - self.cvar_weight) * 1.0 + self.cvar_weight * w
            adv[s:t, env_idx] *= w

        buffer.advantages = adv
        self.logger.record("train/cvar_var_threshold", var_thr)
        self.logger.record("train/cvar_tail_segments", n_tail)

    def train(self) -> None:
        # IMPORTANT: apply CVaR weighting right before PPO update
        if hasattr(self, "rollout_buffer") and self.rollout_buffer is not None:
            self._apply_cvar_weights(self.rollout_buffer)
        super().train()
