"""
Updated Training Script Section - GSNR QoT Provider

This shows the modifications needed in train.py to use GSNRQoTProvider
instead of SimpleQoTProvider.

Replace the QoT provider setup section in training/train.py
"""

# =============================================================================
# MODIFIED SECTION: QoT Provider Setup (in prepare_environment_data function)
# =============================================================================

def prepare_environment_data(config_dict: dict):
    """
    Prepare all data needed for environment creation.
    
    Modified to use GSNR-based QoT provider if GSNR data is available.
    """
    net_cfg = config_dict['network']
    traffic_cfg = config_dict['traffic']
    env_cfg = config_dict['env']
    
    print("\n" + "=" * 70)
    print("PREPARING ENVIRONMENT DATA")
    print("=" * 70)
    
    # ... [Steps 1-2: Load topology and compute KSP - unchanged] ...
    
    # =========================================================================
    # Step 3: Setup QoT Provider (MODIFIED)
    # =========================================================================
    print(f"\n[3/6] Setting up QoT provider...")
    
    # Get modulation formats
    modulations = get_default_modulations()
    print(f"      Modulation formats: {len(modulations)}")
    for mod in modulations:
        print(f"        {mod.name}: SE={mod.spectral_efficiency}, "
              f"OSNR≥{mod.minimum_osnr:.1f}dB")
    
    # Check if GSNR data is available
    gsnr_data_path = config_dict['network'].gsnr_data_path  # NEW CONFIG OPTION
    use_gsnr = (gsnr_data_path is not None and 
                os.path.exists(gsnr_data_path))
    
    if use_gsnr:
        print(f"\n      Using GSNR-based QoT provider")
        print(f"      GSNR data: {gsnr_data_path}")
        
        from utils.qot import GSNRQoTProvider
        
        qot_provider = GSNRQoTProvider(
            gsnr_data_path=gsnr_data_path,
            modulations=modulations,
            ksp_dict=ksp_dict,
            channel_spacing_ghz=50.0,  # Precomputed with 50 GHz
            slot_bandwidth_ghz=net_cfg.slot_bandwidth_ghz  # Provision with 12.5 GHz
        )
        
        print(f"      Channel spacing: 50 GHz")
        print(f"      Slot bandwidth: {net_cfg.slot_bandwidth_ghz} GHz")
        print(f"      Slots per channel: {int(50.0 / net_cfg.slot_bandwidth_ghz)}")
        
        # Test QoT
        test_path_id = list(qot_provider.path_id_map.keys())[0]
        test_gsnr = qot_provider.get_slot_gsnr(test_path_id, 0, 10)
        print(f"      Sample GSNR (path {test_path_id}, slots 0-9): "
              f"[{test_gsnr.min():.1f}, {test_gsnr.max():.1f}] dB")
        
    else:
        print(f"\n      Using simple length-based QoT provider")
        print(f"      (No GSNR data available)")
        
        from utils.qot import SimpleQoTProvider
        
        # Build path length dictionary
        path_lengths = {}
        for paths in ksp_dict.values():
            for path in paths:
                path_lengths[path.path_id] = path.length
        
        qot_provider = SimpleQoTProvider(modulations, path_lengths)
        print(f"      Paths tracked: {len(path_lengths)}")
    
    print(f"      ✓ QoT provider ready")
    
    # ... [Steps 4-6: Criticality, Encoder, Traffic - unchanged] ...
    
    return {
        'topology': topology,
        'ksp_dict': ksp_dict,
        'qot_provider': qot_provider,
        'edge_criticality': edge_criticality,
        'encoder': encoder,
        'traffic_generator': traffic_gen,
        'modulations': modulations
    }


# =============================================================================
# EXAMPLE: How to test GSNR loading
# =============================================================================

def test_gsnr_provider(gsnr_path: str, topology_path: str, k_paths: int = 5):
    """
    Test the GSNR QoT provider.
    
    Usage:
        python -c "from train_gsnr import test_gsnr_provider; \
                   test_gsnr_provider('gsnr_data.pkl', 'topology.xlsx')"
    """
    from utils.topology import load_topology, compute_ksp, add_link_ids_to_paths
    from utils.qot import GSNRQoTProvider, get_default_modulations
    
    print("Loading topology...")
    topology = load_topology(topology_path)
    
    print("Computing K-shortest paths...")
    ksp_dict = compute_ksp(topology, k=k_paths)
    add_link_ids_to_paths(topology, ksp_dict)
    
    print("Creating GSNR QoT provider...")
    modulations = get_default_modulations()
    
    qot = GSNRQoTProvider(
        gsnr_data_path=gsnr_path,
        modulations=modulations,
        ksp_dict=ksp_dict,
        channel_spacing_ghz=50.0,
        slot_bandwidth_ghz=12.5
    )
    
    print(f"\nQoT Provider Statistics:")
    print(f"  Paths tracked: {len(qot.path_id_map)}")
    print(f"  Slots per channel: {qot.slots_per_channel}")
    
    # Test a few paths
    print(f"\nSample Path QoT:")
    for i, path_id in enumerate(list(qot.path_id_map.keys())[:5]):
        src, dst, path_idx = qot.path_id_map[path_id]
        
        # Get GSNR for first 100 slots
        gsnr = qot.get_slot_gsnr(path_id, 0, 100)
        
        # Get best modulation
        best_mod = qot.get_best_modulation(path_id, 0, 100)
        
        print(f"  Path {i} ({src} → {dst}, k={path_idx}):")
        print(f"    GSNR range: [{gsnr.min():.2f}, {gsnr.max():.2f}] dB")
        print(f"    Best modulation: {best_mod.name if best_mod else 'None'}")
        if best_mod:
            margin = qot.get_margin_db(path_id, best_mod, 0, 100)
            print(f"    Margin: {margin:.2f} dB")
    
    print("\n✓ GSNR QoT provider test complete!")


if __name__ == "__main__":
    # Example usage
    test_gsnr_provider(
        gsnr_path="gsnr_data/btuk_roadm_all_pairs_ksp_gsnr.pkl",
        topology_path="topologies/topo_us24_txOnly.xlsx",
        k_paths=5
    )
