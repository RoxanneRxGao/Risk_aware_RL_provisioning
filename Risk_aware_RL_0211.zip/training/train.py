"""
Training Script for Risk-Aware Optical Network Provisioning

UPDATED with:
- GSNR-based QoT provider
- Path extraction from GSNR data (fast)
- Automatic fallback when GSNR unavailable
"""
import os
import sys
from pathlib import Path
import time
import argparse
import numpy as np

# Add project root to path
project_root = Path(__file__).parent.parent
sys.path.insert(0, str(project_root))

# RL libraries
from stable_baselines3 import PPO
from stable_baselines3.common.vec_env import DummyVecEnv, SubprocVecEnv
from stable_baselines3.common.callbacks import (
    EvalCallback, CheckpointCallback, CallbackList
)
from stable_baselines3.common.monitor import Monitor

# Try to import MaskablePPO
try:
    from sb3_contrib import MaskablePPO
    from sb3_contrib.common.wrappers import ActionMasker
    MASKABLE_AVAILABLE = True
except ImportError:
    MASKABLE_AVAILABLE = False
    print("Warning: sb3-contrib not installed. Using standard PPO without masking.")

# PyTorch
import torch
from torch import nn

# Project imports
from configs.config import (
    get_default_config, print_config, save_config,
    NetworkConfig, TrafficConfig, EnvConfig, TrainingConfig
)
from utils.topology import (
    load_topology, compute_ksp, add_link_ids_to_paths,
    get_topology_stats
)
from utils.qot import get_default_modulations, SimpleQoTProvider, GSNRQoTProvider
from utils.traffic import TrafficGenerator
from utils.criticality import compute_link_criticality_betweenness
from envs.state_encoder import StateEncoder, EncoderConfig
from envs.risk_aware_env import RiskAwareProvisioningEnv
from models.cvar_ppo import CVaRPPO


def prepare_environment_data(config_dict: dict):
    """
    Prepare all data needed for environment creation.
    
    UPDATED to use:
    1. GSNR-based path extraction (fast, ensures correspondence)
    2. GSNR-based QoT provider (accurate per-channel QoT)
    
    Falls back gracefully if GSNR data not available.
    """
    net_cfg = config_dict['network']
    traffic_cfg = config_dict['traffic']
    env_cfg = config_dict['env']
    
    print("\n" + "=" * 70)
    print("PREPARING ENVIRONMENT DATA")
    print("=" * 70)
    
    # =========================================================================
    # Step 1: Load Network Topology
    # =========================================================================
    print(f"\n[1/6] Loading topology: {net_cfg.topology_name}")
    print(f"      Path: {net_cfg.topology_path}")
    
    topology = load_topology(net_cfg.topology_path, k_paths=net_cfg.k_paths)
    
    stats = get_topology_stats(topology)
    print(f"      Nodes: {stats['num_nodes']}")
    print(f"      Links: {stats['num_physical_links']}")
    print(f"      Avg degree: {stats['avg_degree']:.2f}")
    
    # =========================================================================
    # Step 2: K-Shortest Paths (UPDATED - uses GSNR data when available)
    # =========================================================================
    print(f"\n[2/6] Obtaining K-shortest paths...")
    
    # Check if GSNR data is available
    gsnr_data_path = net_cfg.gsnr_data_path
    
    start_time = time.time()
    
    # Smart path computation: uses GSNR data if available, else computes
    ksp_dict = compute_ksp(
        G=topology,
        k=net_cfg.k_paths,
        gsnr_data_path=gsnr_data_path
    )
    
    # Add link IDs to paths
    add_link_ids_to_paths(topology, ksp_dict)
    
    elapsed = time.time() - start_time
    total_paths = sum(len(paths) for paths in ksp_dict.values())
    
    print(f"      ✓ Total paths: {total_paths}")
    print(f"      ✓ SD pairs: {len(ksp_dict)}")
    print(f"      ✓ Time: {elapsed:.2f}s")
    
    # =========================================================================
    # Step 3: Setup QoT Provider (UPDATED - uses GSNR when available)
    # =========================================================================
    print(f"\n[3/6] Setting up QoT provider...")
    
    # Get modulation formats
    modulations = get_default_modulations()
    print(f"      Modulation formats: {len(modulations)}")
    for mod in modulations:
        print(f"        {mod.name:6s}: SE={mod.spectral_efficiency}, "
              f"OSNR≥{mod.minimum_osnr:.1f}dB, max_dist={mod.maximum_length/1000:.0f}km")
    
    # Check if GSNR data is available
    use_gsnr = (gsnr_data_path is not None and 
                os.path.exists(gsnr_data_path))
    
    if use_gsnr:
        # Use GSNR-based QoT provider (accurate per-channel QoT)
        print(f"\n      Using GSNR-based QoT provider")
        print(f"      GSNR data: {gsnr_data_path}")
        
        qot_provider = GSNRQoTProvider(
            gsnr_data_path=gsnr_data_path,
            modulations=modulations,
            ksp_dict=ksp_dict,
            channel_spacing_ghz=net_cfg.gsnr_channel_spacing_ghz,
            slot_bandwidth_ghz=net_cfg.slot_bandwidth_ghz
        )
        
        print(f"      Channel spacing: {net_cfg.gsnr_channel_spacing_ghz} GHz")
        print(f"      Slot bandwidth: {net_cfg.slot_bandwidth_ghz} GHz")
        print(f"      Slots per channel: {int(net_cfg.gsnr_channel_spacing_ghz / net_cfg.slot_bandwidth_ghz)}")
        
        # Test QoT
        if len(qot_provider.path_id_map) > 0:
            test_path_id = list(qot_provider.path_id_map.keys())[0]
            test_gsnr = qot_provider.get_slot_gsnr(test_path_id, 0, 10)
            print(f"      Sample GSNR (path {test_path_id}, slots 0-9): "
                  f"[{test_gsnr.min():.1f}, {test_gsnr.max():.1f}] dB")
        
    else:
        # Use simple length-based QoT provider (fallback)
        print(f"\n      Using simple length-based QoT provider")
        if gsnr_data_path:
            print(f"      (GSNR data not found: {gsnr_data_path})")
        else:
            print(f"      (No GSNR data configured)")
        
        # Build path length dictionary
        path_lengths = {}
        for paths in ksp_dict.values():
            for path in paths:
                path_lengths[path.path_id] = path.length
        
        qot_provider = SimpleQoTProvider(modulations, path_lengths)
        print(f"      Paths tracked: {len(path_lengths)}")
    
    print(f"      ✓ QoT provider ready")
    
    # =========================================================================
    # Step 4: Compute Link Criticality
    # =========================================================================
    print(f"\n[4/6] Computing link criticality...")
    print(f"      Method: {env_cfg.criticality_method}")
    
    if env_cfg.criticality_method == 'betweenness':
        edge_criticality = compute_link_criticality_betweenness(topology)
    else:
        # Default to betweenness
        edge_criticality = compute_link_criticality_betweenness(topology)
    
    print(f"      Criticality range: [{edge_criticality.min():.3f}, "
          f"{edge_criticality.max():.3f}]")
    print(f"      High-risk threshold (top {env_cfg.highrisk_quantile*100:.0f}%): "
          f"{np.quantile(edge_criticality, 1.0 - env_cfg.highrisk_quantile):.3f}")
    
    # =========================================================================
    # Step 5: Create State Encoder
    # =========================================================================
    print(f"\n[5/6] Creating state encoder...")
    print(f"      Type: {'Original (comprehensive)' if env_cfg.use_original_encoder else 'GNN'}")
    
    if env_cfg.use_original_encoder:
        # Use original comprehensive encoder
        encoder_config = EncoderConfig(
            num_nodes=topology.number_of_nodes(),
            bands=list(range(len(net_cfg.bands))),
            K=net_cfg.k_paths,
            H_max=topology.number_of_nodes(),
            num_mods=len(modulations),
            delta_norm_db=10.0,
            highrisk_q=env_cfg.highrisk_quantile
        )
        
        # Create slots_needed function
        from utils.qot import slots_needed
        def slots_needed_fn(bitrate, modulation, band):
            return slots_needed(
                bitrate,
                modulation.spectral_efficiency,
                net_cfg.slot_bandwidth_ghz,
                net_cfg.guard_band_slots
            )
        
        encoder = StateEncoder(
            cfg=encoder_config,
            num_links=topology.number_of_edges(),
            edge_criticality=edge_criticality,
            qot_provider=qot_provider,
            slots_needed_fn=slots_needed_fn
        )
        
        obs_dim = encoder.obs_dim()
        print(f"      Observation dimension: {obs_dim}")
        print(f"        Request features: {2 * encoder_config.num_nodes + 2}")
        print(f"        Per-link features: {topology.number_of_edges() * len(net_cfg.bands) * 5}")
        print(f"        Candidate features: {net_cfg.k_paths * len(net_cfg.bands) * 8}")
        print(f"        Criticality features: {net_cfg.k_paths * 3}")
    else:
        # Use GNN encoder (if available)
        try:
            from models.gnn_encoder import GNNEncoderWrapper
            encoder = GNNEncoderWrapper(
                topology=topology,
                num_bands=len(net_cfg.bands),
                edge_criticality=edge_criticality,
                embedding_dim=env_cfg.gnn_embedding_dim
            )
            obs_dim = encoder.obs_dim()
            print(f"      GNN embedding dimension: {env_cfg.gnn_embedding_dim}")
            print(f"      Observation dimension: {obs_dim}")
        except ImportError:
            print("      ERROR: GNN encoder not available!")
            print("      Falling back to original encoder...")
            env_cfg.use_original_encoder = True
            # Recursive call with updated config
            return prepare_environment_data(config_dict)
    
    # =========================================================================
    # Step 6: Create Traffic Generator
    # =========================================================================
    print(f"\n[6/6] Creating traffic generator...")
    
    nodes = list(topology.nodes())
    traffic_gen = TrafficGenerator(
        nodes=nodes,
        mean_holding_time=traffic_cfg.mean_service_holding_time,
        mean_inter_arrival=traffic_cfg.mean_service_inter_arrival_time,
        bit_rates=traffic_cfg.bit_rates,
        bit_rate_probs=traffic_cfg.bit_rate_probabilities,
        seed=config_dict['training'].seed
    )
    
    load = traffic_gen.get_load()
    print(f"      Traffic load: {load:.2f} Erlangs")
    print(f"      Mean holding time: {traffic_cfg.mean_service_holding_time:.0f}s")
    print(f"      Mean inter-arrival: {traffic_cfg.mean_service_inter_arrival_time:.2f}s")
    print(f"      Bitrates: {traffic_cfg.bit_rates}")
    
    print("\n" + "=" * 70)
    print("✓ Environment data preparation complete!")
    print("=" * 70 + "\n")
    
    # Return all prepared data
    return {
        'topology': topology,
        'ksp_dict': ksp_dict,
        'qot_provider': qot_provider,
        'edge_criticality': edge_criticality,
        'encoder': encoder,
        'traffic_generator': traffic_gen,
        'modulations': modulations
    }


def make_env(env_data: dict, config_dict: dict, rank: int = 0):
    """
    Factory function to create a single environment instance.
    
    Args:
        env_data: Prepared environment data
        config_dict: Configuration dictionary
        rank: Environment rank (for parallel training)
        
    Returns:
        Callable that creates and returns environment
    """
    def _init():
        net_cfg = config_dict['network']
        env_cfg = config_dict['env']
        train_cfg = config_dict['training']
        
        # Create traffic generator with unique seed
        traffic_gen = TrafficGenerator(
            nodes=list(env_data['topology'].nodes()),
            mean_holding_time=config_dict['traffic'].mean_service_holding_time,
            mean_inter_arrival=config_dict['traffic'].mean_service_inter_arrival_time,
            bit_rates=config_dict['traffic'].bit_rates,
            bit_rate_probs=config_dict['traffic'].bit_rate_probabilities,
            seed=train_cfg.seed + rank
        )
        
        # Create environment
        env = RiskAwareProvisioningEnv(
            topology=env_data['topology'],
            ksp_dict=env_data['ksp_dict'],
            qot_provider=env_data['qot_provider'],
            edge_criticality=env_data['edge_criticality'],
            encoder=env_data['encoder'],
            bands=list(range(len(net_cfg.bands))),
            slots_per_band=net_cfg.slots_per_band,
            slot_bandwidth_ghz=net_cfg.slot_bandwidth_ghz,
            guard_slots=net_cfg.guard_band_slots,
            K=net_cfg.k_paths,
            episode_length=env_cfg.episode_length,
            traffic_generator=traffic_gen,
            use_action_masking=env_cfg.use_mask,
            reward_scheme=env_cfg.reward_scheme,
            reward_accept_base=env_cfg.reward_accept_base,
            reward_block_base=env_cfg.reward_block_base,
            bitrate_normalization=env_cfg.bitrate_normalization,
            criticality_penalty_weight=env_cfg.criticality_penalty_weight,
            seed=train_cfg.seed + rank
        )
        
        # Wrap with Monitor
        log_dir = train_cfg.log_dir
        os.makedirs(log_dir, exist_ok=True)
        env = Monitor(
            env,
            filename=os.path.join(log_dir, f'monitor_{rank}'),
            info_keywords=('episode_service_blocking_rate', 'episode_bit_rate_blocking_rate')
        )
        
        # Wrap with ActionMasker if using masking
        if env_cfg.use_mask and MASKABLE_AVAILABLE:
            env = ActionMasker(env, lambda e: e.action_masks())
        
        return env
    
    return _init


def train(config_dict: dict = None):
    """
    Main training function.
    
    Args:
        config_dict: Configuration dictionary (None = use defaults)
        
    Returns:
        Trained agent
    """
    # Load configuration
    if config_dict is None:
        config_dict = get_default_config()
    
    train_cfg = config_dict['training']
    env_cfg = config_dict['env']
    
    # Print configuration
    print_config(config_dict)
    
    # Prepare environment data
    env_data = prepare_environment_data(config_dict)
    
    # Create log directory
    os.makedirs(train_cfg.log_dir, exist_ok=True)
    os.makedirs(os.path.join(train_cfg.log_dir, 'checkpoints'), exist_ok=True)
    
    # Save configuration
    config_path = os.path.join(train_cfg.log_dir, 'config.json')
    save_config(config_dict, config_path)
    
    # =========================================================================
    # Create Training Environments
    # =========================================================================
    print("\n" + "=" * 70)
    print("CREATING TRAINING ENVIRONMENTS")
    print("=" * 70)
    print(f"\nNumber of parallel environments: {train_cfg.n_envs}")
    
    if train_cfg.n_envs == 1:
        # Single environment (for debugging)
        env = DummyVecEnv([make_env(env_data, config_dict, rank=0)])
        print("Using DummyVecEnv (single process)")
    else:
        # Multi-process parallel environments
        env = SubprocVecEnv([
            make_env(env_data, config_dict, rank=i)
            for i in range(train_cfg.n_envs)
        ])
        print("Using SubprocVecEnv (multi-process)")
    
    print("✓ Training environments created\n")
    
    # Create evaluation environment
    eval_env = DummyVecEnv([make_env(env_data, config_dict, rank=9999)])
    print("✓ Evaluation environment created\n")
    
    # =========================================================================
    # Configure PPO Agent
    # =========================================================================
    print("=" * 70)
    print("CONFIGURING RL AGENT")
    print("=" * 70)
    
    # Network architecture
    policy_kwargs = {
        'net_arch': train_cfg.net_arch,
        'activation_fn': nn.ReLU if train_cfg.activation_fn == 'relu' else nn.Tanh
    }
    
    print(f"\nAlgorithm: {'CVaRPPO' if train_cfg.use_cvar else 'PPO'}")
    print(f"Policy architecture:")
    print(f"  Actor (pi): {train_cfg.net_arch[0]['pi']}")
    print(f"  Critic (vf): {train_cfg.net_arch[0]['vf']}")
    print(f"  Activation: {train_cfg.activation_fn}")
    
    print(f"\nHyperparameters:")
    print(f"  Learning rate: {train_cfg.learning_rate}")
    print(f"  Batch size: {train_cfg.batch_size}")
    print(f"  N steps: {train_cfg.n_steps}")
    print(f"  N epochs: {train_cfg.n_epochs}")
    print(f"  Gamma: {train_cfg.gamma}")
    print(f"  GAE lambda: {train_cfg.gae_lambda}")
    print(f"  Clip range: {train_cfg.clip_range}")
    print(f"  Device: {train_cfg.device}")
    print(f"  Seed: {train_cfg.seed}")
    
    # Create agent
    if train_cfg.use_cvar:
        agent = CVaRPPO(
            "MlpPolicy",
            env,
            learning_rate=train_cfg.learning_rate,
            n_steps=train_cfg.n_steps,
            batch_size=train_cfg.batch_size,
            n_epochs=train_cfg.n_epochs,
            gamma=train_cfg.gamma,
            gae_lambda=train_cfg.gae_lambda,
            clip_range=train_cfg.clip_range,
            ent_coef=train_cfg.ent_coef,
            vf_coef=train_cfg.vf_coef,
            max_grad_norm=train_cfg.max_grad_norm,
            policy_kwargs=policy_kwargs,
            verbose=1,
            device=train_cfg.device,
            seed=train_cfg.seed,
            tensorboard_log=train_cfg.log_dir
        )
    elif not train_cfg.use_cvar and env_cfg.use_mask and MASKABLE_AVAILABLE:
        agent = MaskablePPO(
            "MlpPolicy",
            env,
            learning_rate=train_cfg.learning_rate,
            n_steps=train_cfg.n_steps,
            batch_size=train_cfg.batch_size,
            n_epochs=train_cfg.n_epochs,
            gamma=train_cfg.gamma,
            gae_lambda=train_cfg.gae_lambda,
            clip_range=train_cfg.clip_range,
            ent_coef=train_cfg.ent_coef,
            vf_coef=train_cfg.vf_coef,
            max_grad_norm=train_cfg.max_grad_norm,
            policy_kwargs=policy_kwargs,
            verbose=1,
            device=train_cfg.device,
            seed=train_cfg.seed,
            tensorboard_log=train_cfg.log_dir
        )
    else:
        agent = PPO(
            "MlpPolicy",
            env,
            learning_rate=train_cfg.learning_rate,
            n_steps=train_cfg.n_steps,
            batch_size=train_cfg.batch_size,
            n_epochs=train_cfg.n_epochs,
            gamma=train_cfg.gamma,
            gae_lambda=train_cfg.gae_lambda,
            clip_range=train_cfg.clip_range,
            ent_coef=train_cfg.ent_coef,
            vf_coef=train_cfg.vf_coef,
            max_grad_norm=train_cfg.max_grad_norm,
            policy_kwargs=policy_kwargs,
            verbose=1,
            device=train_cfg.device,
            seed=train_cfg.seed,
            tensorboard_log=train_cfg.log_dir
        )
    
    print("\n✓ Agent configured\n")
    
    # =========================================================================
    # Setup Callbacks
    # =========================================================================
    print("=" * 70)
    print("CONFIGURING CALLBACKS")
    print("=" * 70)
    
    # Checkpoint callback
    checkpoint_callback = CheckpointCallback(
        save_freq=train_cfg.checkpoint_freq,
        save_path=os.path.join(train_cfg.log_dir, 'checkpoints'),
        name_prefix='ppo_optical',
        save_replay_buffer=False,
        save_vecnormalize=True
    )
    print(f"\n✓ Checkpoint every {train_cfg.checkpoint_freq} steps")
    
    # Evaluation callback
    eval_callback = EvalCallback(
        eval_env,
        best_model_save_path=os.path.join(train_cfg.log_dir, 'best_model'),
        log_path=train_cfg.log_dir,
        eval_freq=train_cfg.eval_freq,
        n_eval_episodes=train_cfg.n_eval_episodes,
        deterministic=True,
        render=False
    )
    print(f"✓ Evaluation every {train_cfg.eval_freq} steps ({train_cfg.n_eval_episodes} episodes)")
    
    # Combine callbacks
    callback = CallbackList([checkpoint_callback, eval_callback])
    
    print("\n✓ Callbacks ready\n")
    
    # =========================================================================
    # Start Training
    # =========================================================================
    print("=" * 70)
    print("STARTING TRAINING")
    print("=" * 70)
    
    expected_episodes = train_cfg.total_timesteps // (train_cfg.n_envs * env_cfg.episode_length)
    print(f"\nTotal timesteps: {train_cfg.total_timesteps:,}")
    print(f"Expected episodes: ~{expected_episodes:,}")
    print(f"Training started at: {time.strftime('%Y-%m-%d %H:%M:%S')}")
    print("\n" + "-" * 70 + "\n")
    
    start_time = time.time()
    
    try:
        agent.learn(
            total_timesteps=train_cfg.total_timesteps,
            callback=callback,
            progress_bar=True
        )
    except KeyboardInterrupt:
        print("\n\n⚠️  Training interrupted by user!")
    
    end_time = time.time()
    training_time = end_time - start_time
    
    # =========================================================================
    # Save Final Model
    # =========================================================================
    print("\n" + "-" * 70)
    print("\n" + "=" * 70)
    print("TRAINING COMPLETE")
    print("=" * 70)
    
    print(f"\nTraining time: {training_time/3600:.2f} hours ({training_time/60:.1f} minutes)")
    print(f"Timesteps per second: {train_cfg.total_timesteps/training_time:.0f}")
    
    # Save final model
    final_model_path = os.path.join(train_cfg.log_dir, 'final_model')
    agent.save(final_model_path)
    print(f"\n✓ Final model saved to: {final_model_path}")
    
    # Save training summary
    summary = {
        'total_timesteps': train_cfg.total_timesteps,
        'training_time_hours': training_time / 3600,
        'timesteps_per_second': train_cfg.total_timesteps / training_time,
        'final_model_path': final_model_path,
        'config_path': config_path,
        'used_gsnr_qot': config_dict['network'].gsnr_data_path is not None
    }
    
    import json
    summary_path = os.path.join(train_cfg.log_dir, 'training_summary.json')
    with open(summary_path, 'w') as f:
        json.dump(summary, f, indent=2)
    print(f"✓ Training summary saved to: {summary_path}")
    
    print("\n" + "=" * 70 + "\n")
    
    # Close environments
    env.close()
    eval_env.close()
    
    return agent


def evaluate(model_path: str, n_episodes: int = 10):
    """
    Evaluate a trained model.
    
    Args:
        model_path: Path to saved model
        n_episodes: Number of episodes to evaluate
    """
    print("\n" + "=" * 70)
    print("EVALUATING MODEL")
    print("=" * 70)
    print(f"\nModel: {model_path}")
    print(f"Episodes: {n_episodes}\n")
    
    # Load configuration (should be in same directory as model)
    model_dir = os.path.dirname(model_path)
    config_path = os.path.join(model_dir, 'config.json')
    
    if os.path.exists(config_path):
        from configs.config import load_config
        config_dict = load_config(config_path)
    else:
        print("Warning: Config file not found, using defaults")
        config_dict = get_default_config()
    
    # Prepare environment data
    env_data = prepare_environment_data(config_dict)
    
    # Create evaluation environment
    env_fn = make_env(env_data, config_dict, rank=0)
    env = env_fn()
    
    # Load model
    print(f"Loading model from {model_path}...")
    
    if config_dict['env'].use_mask and MASKABLE_AVAILABLE:
        agent = MaskablePPO.load(model_path)
    else:
        agent = PPO.load(model_path)
    
    print("✓ Model loaded\n")
    
    # Evaluate
    print(f"Running {n_episodes} episodes...\n")
    
    episode_rewards = []
    service_blocking_rates = []
    bitrate_blocking_rates = []
    
    for ep in range(n_episodes):
        obs, _ = env.reset()
        done = False
        episode_reward = 0.0
        
        while not done:
            action, _ = agent.predict(obs, deterministic=True)
            obs, reward, terminated, truncated, info = env.step(action)
            done = terminated or truncated
            episode_reward += reward
        
        episode_rewards.append(episode_reward)
        
        if 'episode_service_blocking_rate' in info:
            service_blocking_rates.append(info['episode_service_blocking_rate'])
        if 'episode_bit_rate_blocking_rate' in info:
            bitrate_blocking_rates.append(info['episode_bit_rate_blocking_rate'])
        
        print(f"  Episode {ep+1}/{n_episodes}: "
              f"reward={episode_reward:.1f}, "
              f"SBR={service_blocking_rates[-1]:.4f if service_blocking_rates else 'N/A'}, "
              f"BBR={bitrate_blocking_rates[-1]:.4f if bitrate_blocking_rates else 'N/A'}")
    
    # Print summary
    print("\n" + "=" * 70)
    print("EVALUATION RESULTS")
    print("=" * 70)
    print(f"\nMean episode reward: {np.mean(episode_rewards):.2f} ± {np.std(episode_rewards):.2f}")
    
    if service_blocking_rates:
        print(f"Mean service blocking rate: {np.mean(service_blocking_rates):.4f} ± {np.std(service_blocking_rates):.4f}")
    
    if bitrate_blocking_rates:
        print(f"Mean bitrate blocking rate: {np.mean(bitrate_blocking_rates):.4f} ± {np.std(bitrate_blocking_rates):.4f}")
    
    print("\n" + "=" * 70 + "\n")
    
    env.close()


def main():
    """Main entry point."""
    parser = argparse.ArgumentParser(
        description="Train Risk-Aware Optical Network Provisioning Agent with GSNR QoT"
    )
    parser.add_argument(
        '--mode',
        type=str,
        default='train',
        choices=['train', 'eval'],
        help='Mode: train or eval'
    )
    parser.add_argument(
        '--model',
        type=str,
        default=None,
        help='Model path (for eval mode)'
    )
    parser.add_argument(
        '--timesteps',
        type=int,
        default=None,
        help='Total training timesteps (overrides config)'
    )
    parser.add_argument(
        '--n-envs',
        type=int,
        default=None,
        help='Number of parallel environments (overrides config)'
    )
    parser.add_argument(
        '--log-dir',
        type=str,
        default=None,
        help='Log directory (overrides config)'
    )
    parser.add_argument(
        '--gsnr-data',
        type=str,
        default=None,
        help='Path to GSNR data file (overrides config)'
    )
    
    args = parser.parse_args()
    
    if args.mode == 'train':
        # Training mode
        config = get_default_config()

        topology_name = 'BTUK'
        config['network'].topology_name = topology_name
        config['network'].topology_path = f"config_files/topo_{topology_name.lower()}_txOnly.xlsx"
        config['network'].gsnr_data_path = f"config_files/{topology_name.lower()}_roadm_all_pairs_ksp_gsnr.pkl"

        # Bit-rate weighted rewards
        config['env'].reward_scheme = 'bitrate_weighted'
        config['env'].bitrate_normalization = max(config['traffic'].bit_rates)

        # CVaR optimization
        config['training'].use_cvar = True
        config['training'].cvar_alpha = 0.1  # Worst 10%
        config['training'].cvar_weight = 0.5  # Balanced
        
        # Override with command line arguments
        if args.timesteps:
            config['training'].total_timesteps = args.timesteps
        if args.n_envs:
            config['training'].n_envs = args.n_envs
        if args.log_dir:
            config['training'].log_dir = args.log_dir
        if args.gsnr_data:
            config['network'].gsnr_data_path = args.gsnr_data
        
        train(config)
        
    elif args.mode == 'eval':
        # Evaluation mode
        if args.model is None:
            print("Error: Please specify --model for evaluation mode")
            sys.exit(1)
        
        evaluate(args.model, n_episodes=10)


if __name__ == "__main__":
    main()
