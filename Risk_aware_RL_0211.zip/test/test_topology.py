"""
Test script to verify topology loading and basic functionality
"""
import sys
sys.path.insert(0, '..')

from utils.topology import load_topology, compute_ksp, add_link_ids_to_paths, get_topology_stats
from utils.qot import get_default_modulations, SimpleQoTProvider, GSNRQoTProvider
from utils.criticality import compute_link_criticality_betweenness
from configs.config import get_default_config

print("="*70)
print("TOPOLOGY LOADING TEST")
print("="*70)

# Get configuration
config = get_default_config()

topology_name = 'BTUK'
config['network'].topology_name = topology_name
config['network'].topology_path = f"config_files/topo_{topology_name.lower()}_txOnly.xlsx"
config['network'].gsnr_data_path = f"config_files/{topology_name.lower()}_roadm_all_pairs_ksp_gsnr.pkl"
topology_path = config['network'].topology_path

print(f"\nTopology file: {topology_path}")

# Load topology
print("\n[1/5] Loading topology...")
G = load_topology(topology_path, k_paths=config['network'].k_paths)

stats = get_topology_stats(G)
print(f"  ✓ Loaded successfully!")
print(f"  Nodes: {stats['num_nodes']}")
print(f"  Physical Links: {stats['num_physical_links']}")
print(f"  Avg degree: {stats['avg_degree']:.2f}")

# Sample nodes and edges
print(f"\n  Node list: {sorted(list(G.nodes()))}")

print(f"\n  Sample edges (first 10):")
for i, (u, v, data) in enumerate(G.edges(data=True)):
    if i >= 10:
        break
    source_full = data.get('source_full', f'Node {u}')
    dest_full = data.get('destination_full', f'Node {v}')
    print(f"    {u} <-> {v}: {data['length']:.0f} km ({source_full} <-> {dest_full})")

# Compute K-shortest paths
print(f"\n[2/5] Computing K-shortest paths (K={config['network'].k_paths})...")
ksp = compute_ksp(G, k=config['network'].k_paths, gsnr_data_path=config['network'].gsnr_data_path)
add_link_ids_to_paths(G, ksp)

total_paths = sum(len(paths) for paths in ksp.values())
print(f"  ✓ Computed {len(ksp)} SD pairs, {total_paths} total paths")

# Show example paths
src, dst = list(ksp.keys())[0]
paths = ksp[(src, dst)]
print(f"\n  Example: Paths from node {src} to node {dst}:")
for i, path in enumerate(paths):
    print(f"    Path {i+1}: {' -> '.join(path.node_list)} "
          f"({path.length:.0f} km, {path.hops} hops)")

# Setup QoT provider
print(f"\n[3/5] Setting up QoT provider...")
modulations = get_default_modulations()
path_lengths = {p.path_id: p.length for paths in ksp.values() for p in paths}
qot = SimpleQoTProvider(modulations, path_lengths)

print(f"  ✓ QoT provider ready")
print(f"  Modulations: {[m.name for m in modulations]}")

# Test QoT for a path
test_path = paths[0]
feasible_mods = qot.get_feasible_modulations(test_path.path_id)
best_mod = qot.get_best_modulation(test_path.path_id)

print(f"\n  Test path (length={test_path.length:.0f} km):")
print(f"    Feasible modulations: {[m.name for m in feasible_mods]}")
print(f"    Best modulation: {best_mod.name if best_mod else 'None'} "
      f"(SE={best_mod.spectral_efficiency if best_mod else 'N/A'})")

# Compute criticality
print(f"\n[4/5] Computing link criticality...")
edge_criticality = compute_link_criticality_betweenness(G)

print(f"  ✓ Criticality computed")
print(f"  Range: [{edge_criticality.min():.3f}, {edge_criticality.max():.3f}]")
print(f"  Mean: {edge_criticality.mean():.3f}")

# Most critical links
top_k = 5
top_indices = edge_criticality.argsort()[-top_k*2:][::-2]
print(f"\n  Top {top_k} most critical links:")
for idx in top_indices:
    # Find edge with this index
    for u, v, data in G.edges(data=True):
        if data['index'] == idx:
            print(f"    Link {idx}: {u} <-> {v} (criticality={edge_criticality[idx]:.3f})")
            break

# Test environment creation
print(f"\n[5/5] Testing environment components...")

from envs.state_encoder import StateEncoder, EncoderConfig
from utils.traffic import TrafficGenerator

# Create encoder config
encoder_cfg = EncoderConfig(
    num_nodes=G.number_of_nodes(),
    bands=list(range(len(config['network'].bands))),
    K=config['network'].k_paths,
    H_max=G.number_of_nodes(),
    num_mods=len(modulations),
    delta_norm_db=10.0
)

# Create slots_needed function
from utils.qot import slots_needed
def slots_needed_fn(bitrate, modulation, band):
    return slots_needed(
        bitrate,
        modulation.spectral_efficiency,
        config['network'].slot_bandwidth_ghz,
        config['network'].guard_band_slots
    )

# Create encoder
encoder = StateEncoder(
    cfg=encoder_cfg,
    num_links=G.number_of_edges(),
    edge_criticality=edge_criticality,
    qot_provider=qot,
    slots_needed_fn=slots_needed_fn
)

obs_dim = encoder.obs_dim()
print(f"  ✓ State encoder created")
print(f"  Observation dimension: {obs_dim}")

# Create traffic generator
nodes = list(G.nodes())
traffic_gen = TrafficGenerator(
    nodes=nodes,
    mean_holding_time=config['traffic'].mean_service_holding_time,
    mean_inter_arrival=config['traffic'].mean_service_inter_arrival_time,
    bit_rates=config['traffic'].bit_rates,
    seed=42
)

print(f"  ✓ Traffic generator created")
print(f"  Load: {traffic_gen.get_load():.2f} Erlangs")

# Generate a test service
service = traffic_gen.generate_service()
print(f"\n  Test service generated:")
print(f"    {service.source} -> {service.destination}")
print(f"    Bitrate: {service.bit_rate} Gbps")
print(f"    Arrival: {service.arrival_time:.2f}s")
print(f"    Holding: {service.holding_time:.2f}s")

print("\n" + "="*70)
print("✅ ALL TESTS PASSED!")
print("="*70)
print("\nYour setup is ready for training!")
print("Run: python training/train.py --timesteps 10000 --n-envs 2")
print("="*70)
