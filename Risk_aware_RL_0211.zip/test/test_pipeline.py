"""
Quick Test Script

Tests that all components work together with the US24 topology.
"""
import sys
sys.path.insert(0, '..')

from configs.config import get_default_config, print_config
from utils.topology import load_topology, compute_ksp, add_link_ids_to_paths, get_topology_stats
from utils.qot import get_default_modulations, SimpleQoTProvider
from utils.criticality import compute_link_criticality_betweenness
from utils.traffic import TrafficGenerator

def test_pipeline():
    """Test the complete data preparation pipeline."""
    
    print("="*70)
    print("TESTING COMPLETE PIPELINE")
    print("="*70)
    
    # 1. Load configuration
    print("\n[1/6] Loading configuration...")
    config = get_default_config()

    topology_name = 'BTUK'
    config['network'].topology_name = topology_name
    config['network'].topology_path = f"config_files/topo_{topology_name.lower()}_txOnly.xlsx"
    config['network'].gsnr_data_path = f"config_files/{topology_name.lower()}_roadm_all_pairs_ksp_gsnr.pkl"
    topology_path = config['network'].topology_path

    print(f"✓ Topology: {config['network'].topology_name}")
    print(f"✓ Path: {config['network'].topology_path}")
    
    # 2. Load topology
    print("\n[2/6] Loading topology...")
    topology = load_topology(config['network'].topology_path)
    stats = get_topology_stats(topology)
    print(f"✓ Nodes: {stats['num_nodes']}")
    print(f"✓ Physical Links: {stats['num_physical_links']}")
    print(f"✓ Avg degree: {stats['avg_degree']:.2f}")
    
    # 3. Compute K-shortest paths
    print(f"\n[3/6] Computing {config['network'].k_paths}-shortest paths...")
    ksp_dict = compute_ksp(topology, k=config['network'].k_paths, gsnr_data_path=config['network'].gsnr_data_path)
    add_link_ids_to_paths(topology, ksp_dict)
    total_paths = sum(len(paths) for paths in ksp_dict.values())
    print(f"✓ Total paths: {total_paths}")
    print(f"✓ SD pairs: {len(ksp_dict)}")
    
    # Show example
    example_key = list(ksp_dict.keys())[0]
    example_paths = ksp_dict[example_key]
    print(f"\nExample: Paths from {example_key[0]} to {example_key[1]}:")
    for i, path in enumerate(example_paths[:3]):
        print(f"  Path {i+1}: {' -> '.join(path.node_list)} ({path.length:.0f} km, {path.hops} hops)")
    
    # 4. Setup QoT provider
    print(f"\n[4/6] Setting up QoT provider...")
    modulations = get_default_modulations()
    path_lengths = {path.path_id: path.length for paths in ksp_dict.values() for path in paths}
    qot_provider = SimpleQoTProvider(modulations, path_lengths)
    print(f"✓ Modulations: {len(modulations)}")
    print(f"✓ Paths tracked: {len(path_lengths)}")
    
    # Test QoT
    test_path = example_paths[0]
    best_mod = qot_provider.get_best_modulation(test_path.path_id)
    print(f"\nExample QoT for path {test_path.path_id} ({test_path.length:.0f} km):")
    print(f"  Best modulation: {best_mod.name if best_mod else 'None'}")
    if best_mod:
        print(f"  Spectral efficiency: {best_mod.spectral_efficiency}")
    
    # 5. Compute criticality
    print(f"\n[5/6] Computing link criticality...")
    edge_criticality = compute_link_criticality_betweenness(topology)
    print(f"✓ Criticality range: [{edge_criticality.min():.3f}, {edge_criticality.max():.3f}]")
    
    # 6. Create traffic generator
    print(f"\n[6/6] Creating traffic generator...")
    nodes = list(topology.nodes())
    traffic_gen = TrafficGenerator(
        nodes=nodes,
        mean_holding_time=config['traffic'].mean_service_holding_time,
        mean_inter_arrival=config['traffic'].mean_service_inter_arrival_time,
        bit_rates=config['traffic'].bit_rates,
        bit_rate_probs=config['traffic'].bit_rate_probabilities,
        seed=42
    )
    print(f"✓ Traffic load: {traffic_gen.get_load():.2f} Erlangs")
    
    # Generate example service
    service = traffic_gen.generate_service()
    print(f"\nExample service:")
    print(f"  {service.source} -> {service.destination}")
    print(f"  Bitrate: {service.bit_rate} Gbps")
    print(f"  Holding time: {service.holding_time:.1f}s")
    
    print("\n" + "="*70)
    print("✓ ALL TESTS PASSED!")
    print("="*70)
    print("\nYou can now run:")
    print("  python training/train.py --timesteps 10000 --n-envs 2")
    print("\n" + "="*70)


if __name__ == "__main__":
    test_pipeline()
