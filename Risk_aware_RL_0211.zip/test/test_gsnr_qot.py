"""
Test Script for GSNR QoT Provider

This standalone script tests the GSNRQoTProvider with your data.
Place this in the project root and run:
    python test_gsnr_qot.py
"""
import sys
import pickle
import numpy as np

# Mock minimal classes for testing
from dataclasses import dataclass
from typing import List

@dataclass
class Path:
    path_id: int
    node_list: List[str]
    hops: int
    length: float
    links_id: np.ndarray = None

@dataclass  
class Modulation:
    name: str
    maximum_length: float
    spectral_efficiency: float
    minimum_osnr: float = None
    inband_xt: float = None


def test_gsnr_loading():
    """Test loading and basic GSNR operations."""
    
    print("="*70)
    print("TESTING GSNR QOT PROVIDER")
    print("="*70)
    
    # Load GSNR data
    gsnr_path = "../config_files/btuk_roadm_all_pairs_ksp_gsnr.pkl"
    
    print(f"\n[1/4] Loading GSNR data from: {gsnr_path}")
    try:
        with open(gsnr_path, 'rb') as f:
            gsnr_data = pickle.load(f)
        print(f"✓ Loaded {len(gsnr_data)} source-destination pairs")
    except FileNotFoundError:
        print(f"✗ File not found: {gsnr_path}")
        print("  Make sure the file is in gsnr_data/ directory")
        return
    
    # Examine structure
    print(f"\n[2/4] Examining GSNR data structure...")
    first_key = list(gsnr_data.keys())[0]
    first_paths = gsnr_data[first_key]
    
    print(f"  Sample pair: {first_key}")
    print(f"  Number of paths (K): {len(first_paths)}")
    
    first_path_data = first_paths[0]
    print(f"  Path data keys: {list(first_path_data.keys())}")
    print(f"  Number of channels: {len(first_path_data['gsnr_db'])}")
    
    gsnr_values = np.array(first_path_data['gsnr_db'])
    print(f"  GSNR range: [{gsnr_values.min():.2f}, {gsnr_values.max():.2f}] dB")
    
    # Check channel spacing
    freqs_hz = first_path_data['frequency_hz']
    if len(freqs_hz) > 1:
        spacing_ghz = (freqs_hz[1] - freqs_hz[0]) / 1e9
        print(f"  Channel spacing: {spacing_ghz:.1f} GHz")
    
    # Test slot expansion
    print(f"\n[3/4] Testing 50 GHz → 12.5 GHz slot mapping...")
    slot_bandwidth_ghz = 12.5
    channel_spacing_ghz = 50.0
    slots_per_channel = int(channel_spacing_ghz / slot_bandwidth_ghz)
    
    print(f"  Slots per channel: {slots_per_channel}")
    
    # Expand GSNR to slot level
    channel_gsnr = np.array(first_path_data['gsnr_db'])
    slot_gsnr = np.repeat(channel_gsnr, slots_per_channel)
    
    print(f"  Original channels: {len(channel_gsnr)}")
    print(f"  Expanded slots: {len(slot_gsnr)}")
    print(f"  Slot GSNR range: [{slot_gsnr.min():.2f}, {slot_gsnr.max():.2f}] dB")
    
    # Example allocation
    print(f"\n  Example: Allocate 8 slots starting at slot 100")
    start_slot = 100
    num_slots = 8
    allocated_gsnr = slot_gsnr[start_slot:start_slot+num_slots]
    
    print(f"    GSNR for slots {start_slot}-{start_slot+num_slots-1}:")
    print(f"    {allocated_gsnr}")
    print(f"    Min GSNR: {allocated_gsnr.min():.2f} dB")
    
    # Test modulation feasibility
    print(f"\n[4/4] Testing modulation feasibility...")
    
    modulations = [
        Modulation("BPSK", 100_000, 1, 12.6),
        Modulation("QPSK", 2_000, 2, 15.6),
        Modulation("8QAM", 1_000, 3, 18.6),
        Modulation("16QAM", 500, 4, 22.4),
        Modulation("32QAM", 250, 5, 26.4),
        Modulation("64QAM", 125, 6, 30.4),
    ]
    
    min_gsnr = allocated_gsnr.min()
    
    print(f"  Available GSNR: {min_gsnr:.2f} dB")
    print(f"\n  Feasible modulations:")
    for mod in modulations:
        if min_gsnr >= mod.minimum_osnr:
            margin = min_gsnr - mod.minimum_osnr
            print(f"    ✓ {mod.name:6s} (SE={mod.spectral_efficiency}, "
                  f"req≥{mod.minimum_osnr:.1f}dB, margin={margin:.1f}dB)")
        else:
            deficit = mod.minimum_osnr - min_gsnr
            print(f"    ✗ {mod.name:6s} (SE={mod.spectral_efficiency}, "
                  f"req≥{mod.minimum_osnr:.1f}dB, deficit={deficit:.1f}dB)")
    
    # Best modulation
    best = None
    for mod in reversed(modulations):  # Start from highest SE
        if min_gsnr >= mod.minimum_osnr:
            best = mod
            break
    
    if best:
        print(f"\n  Best modulation: {best.name} (SE={best.spectral_efficiency})")
    else:
        print(f"\n  No feasible modulation (GSNR too low)")
    
    print("\n" + "="*70)
    print("✓ ALL TESTS PASSED!")
    print("="*70)
    print("\nYou can now use GSNRQoTProvider in your training:")
    print("  1. Copy qot.py to utils/qot.py")
    print("  2. Update config to set gsnr_data_path")
    print("  3. Update train.py to use GSNRQoTProvider")
    print("="*70)


if __name__ == "__main__":
    test_gsnr_loading()
